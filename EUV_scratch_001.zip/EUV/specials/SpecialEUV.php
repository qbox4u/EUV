<?php
 /******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */


class SpecialEUV extends SpecialPage {
	
	
	public function __construct() {
		parent::__construct( 'EUVAdmin' );
	}

const B_TagTest = <<<QBoxFSP

=Testing the functionality=

====Tags====
{|class="wikitable sortable mw-collapsible mw-collapsed" style="white-space: nowrap;font-size:12px;"text-align:left;" width=80%
| style="text-align:left;"|'''TEST <nowiki><EUV const1=aaa const2=bbbb> Hallo World </EUV></nowiki>'''
|- style="vertical-align: top;"
|
 <nowiki><EUV const1=aaa const2=bbbb> Hallo World </EUV></nowiki>
<EUV const1=aaa const2=bbbb> Hallo World </EUV>
|}

{|class="wikitable sortable mw-collapsible mw-collapsed" style="white-space: nowrap;font-size:12px;" width=80%
| style="text-align:left;"|'''TEST <nowiki>{{#EUV:Hallo|World}}</nowiki></nowiki>'''
|- style="vertical-align: top;"
|
 <nowiki>{{#EUV:Hallo|World}}</nowiki>
{{#EUV:Hallo|World}}
|}

QBoxFSP;

	/**
	 * Show the page to the user
	 *
	 * @param string $sub The subpage string argument (if any).
	 *  [[Special:HelloWorld/subpage]].
	 */

	function execute( $par ) {
		global $wgUser,$B_TestPage,$wgScriptPath,$IP;
		
		$output = $this->getOutput();
		$output->setPageTitle( $this->msg( 'euv-helloworld' ) );
		
		$request = $this->getRequest();
		$this->setHeaders();
		
		# ...Add the base instructions from mediawiki
		$output->addHelpLink( 'Extension:EUV' );
		# ...User name
		$a = $wgUser->getName();
		# ...Messages		
		$SpecialPageinfo = "Hello user:$a !<br>";
		$SpecialPageinfo .= $this->msg( 'euv-welcome' )->parse().'<br>';		
		$output->addWikiText( $SpecialPageinfo );
		
		$output->addWikiText( " Update the EUV extension design page:  [[Create_EUV_extension]]" ); 
		$output->addWikiText( " Update the Mediawiki page: [https://www.mediawiki.org/wiki/Extension:EUV Extension:EUV]" ); 
		$output->addWikiText( " Update the GitHub page: [https://github.com/qbox4u/EUV qbox4u EUV]" );	

		$obj = new EUVDispayLoggingfiles();
		$result = $obj->wf_EUV_DispayLoggingfiles();
		$output->addWikiText($result);	
		$output->addWikiText( self::B_TagTest );
		
		# Test: Check the bin location and create an wiki table
		$obj = new EUVphpbinchk();
		$result = $obj->wf_EUV_phpBinlocationCheck();
		$output->addWikiText($result);
		
		# Test: Check and create the default wiki pages
		$DefaultPages = new EUVCreateDefaultPages();
		$result = $DefaultPages->wf_EUV_CreateDefaultPages();
		$output->addWikiText($result);
		
		# Create an table with the presently used classes and functions information
		global $wgEUVFuncCredits;
		$obj = new EUVSetArrayGlobals();
		$result = $obj->wflist_wgEUVFuncinfo();
		$output->addWikiText($result);
		
	}

	protected function getGroupName() {
		return 'other';
	}
}
