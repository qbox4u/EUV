<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */
 
class EUVSetArrayGlobals extends ArrayObject{

		function __construct(){
			
			global $wgEUVFuncCredits;
			
			$wgEUVFuncCredits['EUVSetArrayGlobals'][] = array(
				'class'           		=> 'EUVSetArrayGlobals',
				'Functions'				=> array( 
					'wfnoname'			=> array(
						'help_page'		=> 'Class id none',
						'php_design'	=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Class EUVSetArrayGlobals Create default Class info links',
					),
					'wfnoname4'			=> array(
						'help_page next'	=> 'Class id none',
						'php_design next'	=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Class EUVSetArrayGlobals Create default Class info links',
					),						
				),
				'version'				=> '1.0.0',
				'path'           		=> __FILE__,
				'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
				'description' 			=> 'PHP Master: Class EUVSetArrayGlobals',
				'license-name' 			=> 'Licence',
				'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
			//print'<pre>xxxxxxxxxxxxxxxxxxxxxyyyyyyyxxxxxxxxxxxx'; print_r($wgEUVFuncCredits['EUVSetArrayGlobals'][0]); print'</pre>';
			
			}
			
		
		
	}
