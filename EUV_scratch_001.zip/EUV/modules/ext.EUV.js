( function () {

	/**
	 * @class mw.boilerPlate
	 * @singleton
	 */
	mw.boilerPlate = {
	};

}() );
