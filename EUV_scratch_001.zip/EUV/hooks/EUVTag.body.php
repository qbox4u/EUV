<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVTagBody {
/**********************************
 * ID		: wf_BoilerPlate_TagFunctionRender( $input, array $args, Parser $parser, PPFrame $frame )
 * Release	: NA 
 * Date		: Created 26-10-2016 by JBoe
 * Notes	: Impementation of Boilerplate
 *
 * Purpose	: To retrieve the parameters used inside the TAG
 * Info		: http://php.net/manual/en/function.require-once.php	
 * Function	: Incude parameters 
 * Input	: <TAG11 const1=aaa const2=bbbb> Hallo World </TAG11> 	
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
	public static function wf_EUV_TagFunctionRender( $input, array $args, Parser $parser, PPFrame $frame ) { 
		global $wgUser;

		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_TagFunctionRender");
		$access = $wgUser->isAllowed( 'read' );
		
		$attr = array();
		
		# initialise the secured_attributes array
		$secured_attributes;
    
		# first of all, retrieve the parameters that we have in the hook
		foreach( $args as $name => $value ){
			$a = '<strong>' . htmlspecialchars( $name ) . '</strong> = ' . htmlspecialchars( $value ); 
			$attr[] = $a;
		}
		
		# Add some basic security in the attributes to prevent accepting unwanted characters from cheating users
		foreach( $args as $key => $value){
			# Allow only the following characters inside the tag a-z...A-Z ... underscore, minus,plus, 
			$tmp  = preg_replace('/[^A-Za-z0-9 _\-\+]/','',$value);
			# When the character is the same after the preg_replace, we are allowed to use this 
			if ($tmp === $value){ $secured_attributes[]	= $tmp; }
				# The Character is not allowed, provide an error message to the user
				else { 	$output  = '<strong><p class="error">'. wfMessage( 'euv-argerror' )->parse() . '</p></strong>' ;
						# Highite the illegal Character
						$badvalue = preg_replace('/[^A-Za-z0-9 _\-\+]/','<span style="color:red">'.' '.htmlspecialchars('$0', ENT_QUOTES).' '. '</span>',$value);
						$output .= $key.'='.$badvalue;
						EUVLogging::wf_EUV_DiagnosticsLogging('',"illegal Character ".$key.'='.$badvalue." found inside the Tag");
						EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** <span style='color:red'>Forced exit</span> of wf_EUV_TagFunctionRender");
						# Do not proceed with any parcer function
						return array( $output, 'noparse' => false, 'isHTML' => false);	
						}
		}
		
		# Add some basic security in the INPUT to prevent accepting unwanted characters from cheating users
		$value = $input;
		# Allow only the following characters inside the tag a-z...A-Z ... underscore, minus,plus, 
		$tmp  = preg_replace('/[^A-Za-z0-9 _\-\+]/','',$value);
		# When the character is the same after the preg_replace, we are allowed to use this 
		if ($tmp === $value){ $secured_input = $input; }
			# The Character is not allowed, provide an error message to the user
			else { 	$output  = '<strong><p class="error">'. wfMessage( 'euv-argerror' )->parse() . '</p></strong>' ;
					# Highite the illegal Character
					$badvalue = preg_replace('/[^A-Za-z0-9 _\-\+]/','<span style="color:red">'.' '.htmlspecialchars('$0', ENT_QUOTES).' '. '</span>',$value);	
					$output .= $badvalue;
					EUVLogging::wf_EUV_DiagnosticsLogging('',"illegal Characters found inside the body of the Tag");
					EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** <span style='color:red'>Forced exit</span> of wf_EUV_TagFunctionRender");
					# Do not proceed with any parcer function
					return array( $output, 'noparse' => false, 'isHTML' => false);	
					}
		
		$html_body  = '<strong>'.wfMessage( 'euv-testme' )->parse().'</strong>';		
		$html_body .= "<strong>My first TAG function</strong><br>\n";
		$html_body .= "---- \n";
		$html_body .= "This is my  first typical syntax for a TAG function <strong><nowiki><Tag1 arg1='xxx' arg2='xxx'> my data </Tag1></nowiki></strong><br />\n";	
		$html_body .= 'my Tag hook contains '.count($args)." elements<br>\n";
		$html_body .= '$attributes [0] '.$attr[0]."<br>\n";
		$html_body .= '$attributes [1] '.$attr[1]."<br>\n";
		$html_body .= ' The data between 2 TAGS is:'.htmlspecialchars( $secured_input )."\n";

		$output = $parser->recursiveTagParse( $html_body, $frame );
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_TagFunctionRender");
		
		return array( $output, 'noparse' => false, 'isHTML' => false);
		
	}	
	
}
