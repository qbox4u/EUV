<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVParserBody {	

/**********************************
 * ID		: wf_BoilerPlate_ParserFunction_Render( &$parser )
 * Release	: NA 
 * Date		: Created 26-10-2016 by JBoe
 * Notes	: Impementation of Boilerplate
 *
 * Purpose	: To retrieve the parameters used inside the TAG
 * Info		: http://php.net/manual/en/function.require-once.php	
 * Function	: Incude parameters 
 * Input	: {{#EUV2:Hallo|World}} 	
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
	
	public static function wf_EUV_ParserFunction_Render( &$parser) { 
		global $wgUser;
		
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_ParserFunction_Render");
		# initialise the secured_attributes array
		$secured_attributes;
		$access = $wgUser->isAllowed( 'read' );
		
		# First of all, retrieve the parameters that we have in the hook
		$arg = func_get_args();
		# Remove the first argument.0th parameter is the $parser
		array_shift($arg); 
		
		# Add some basic security in the attributes to prevent accepting unwanted characters from cheating users
		foreach( $arg as $key => $value){
			# Allow only the following characters inside the tag a-z...A-Z ... underscore, minus,plus, 
			$tmp  = preg_replace('/[^A-Za-z0-9 _\-\+]/','',$value);
			# When the character is the same after the preg_replace, we are allowed to use this 
			if ($tmp === $value){ $secured_attributes[]	= $tmp; }
				# The Character is not allowed, provide an error message to the user
				else { 	$output  = '<strong><p class="error">'. wfMessage( 'euv-argerror' )->parse() . '</p></strong>' ;
						# Highite the illegal Character
						$value = preg_replace('/[^A-Za-z0-9 _\-\+]/','<span style="color:red">'.' '.htmlspecialchars('$0', ENT_QUOTES).' '. '</span>',$value);	
						$output .= $value;
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Illegal Character $value found inside the parcer tag");
						EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** <span style='color:red'>Forced exit</span> of wf_EUV_ParserFunction_Render");
						# Do not proceed with any parcer function
						return array( $output, 'noparse' => false, 'isHTML' => false);	
						}
		}
		
		if ( isset($secured_attributes[0]) ) {$secured_required_func = $secured_attributes[0];}
			
			# No valid function is provided with the TAG
			else { 	EUVLogging::wf_EUV_DiagnosticsLogging('',"No function attribute is provided with the parcer tag");
					$secured_required_func = ''; } 
		
		EUVLogging::wf_EUV_DiagnosticsLogging('',"Parcer tag function :<span style='color:blue'>$secured_required_func</span> started");
		# switching {{#EUV2:Function|parm1|parm2|parm x  }} 
		switch ( $secured_required_func ) {

			case 'testptag' :  		$obj = new EUVTestParcerTag; $html_body = $obj->wf_EUV_TestParcerTag( $secured_attributes );	break;
			case 'help' 	:  		$html_body  = '<strong>'.wfMessage( 'euv-peuv2avaltags' )->parse().'</strong>';	break;
			
			default			:		EUVLogging::wf_EUV_DiagnosticsLogging('',"No valid function <span style='color:red'>$secured_required_func</span> is provided with the parcer tag");
									$html_body  = '<strong><p class="error">'.wfMessage( 'euv-peuv2tagerr01' )->parse().'</p></strong>' ;break;
		}
		
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_ParserFunction_Render");
		$output = $html_body;
		
		return array( $output, 'noparse' => false, 'isHTML' => false);
		
	}
	
}
