<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVphpbinchk {
	
/**********************************
 * Class	: EUVphpbinchk
 * ID		: wf_EUV_phpBinlocationCheck
 * Release	: NA 
 * Date		: Created 02-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Check for the location of the php Bin executabe inside the server   
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>    
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_phpBinlocationCheck() { 
		global $IP;
		
		# The php BIN executable ( & path ) inside the QBox Server
		# This path has to be checked on other servers as mutiple versions may reside in your own server !!!!!
		# Perform for QNAP an [~] # ipkg list_installed and check if eg '''php - 5.2.17-2 - The php scripting language''' has been installed  
		# An incorrect method for QNAP is ==>  [~] # which php    or <?php echo shell_exec('which php'); ? >
		# An incorrect method for QNAP is ==>  [~] # whereis php  or <?php echo shell_exec('whereis php'); ? >
		# An possible  method for QNAP is ==>  [~] # find / -name php

		$cmd = 'whoami';
		$Result = shell_exec($cmd);
		//echo '[~] # whoami => result is: '.$Result.'<br>';
		$cmd = 'which php';
		$Result = shell_exec($cmd);
		//echo '[~] # which php => result is: '.$Result.'<br>';
		$cmd = 'whereis php';
		$Result = shell_exec($cmd);
		//echo '[~] # whereis php => result is: '.$Result.'<br>';
		$cmd = 'php -v';
		$Result = shell_exec($cmd);
		//echo '[~] # php -v => result is: '.$Result.'<br>';
		
		# Perform an search for files containing php
		$cmd = 'find / -name php';
		$Shell_FindPathsResult = shell_exec($cmd);
		# create an array with the individua found locations
		$paths = preg_split('/\n/', $Shell_FindPathsResult, -1, PREG_SPLIT_OFFSET_CAPTURE);
		# Retrieve the individual file information
		# eg Array([0] => lrwxrwxrwx  1 admin administ 27 Nov  1 11:30 php.ini -> /etc/default_config/php.ini
		$Shell_LS_Result;
		foreach ($paths as $key =>$serverpath) {
			$cmd = 'ls -l '. $serverpath[0];
			$result = shell_exec($cmd);
			# remove the results that contain an directory , meaning there are multiple \n inside and [0]is ok
			$Shell_LS_Result[] = preg_split('/\n/', $result, -1, PREG_SPLIT_OFFSET_CAPTURE)[0];
			}
		# Select the actual filepath and file name
		$Raw_Result;
		foreach ($Shell_LS_Result as $key =>$serverpath) {
			# remove guarbage at the end of the path and add the path location 
			$Raw_Result[] = rtrim($serverpath[0]);
			}
		# Match all [/php] with nothing behind php in the raw array
		$out  = preg_grep ('#/(.+?)/php$#', $Raw_Result);
		# Trim the actual path from the ls string		
		$pout='';
		foreach ($out as $serverpath){
			preg_match_all( "#/(.+?)/php$#", $serverpath, $p, PREG_SET_ORDER );
			$pout[] = $p[0][0];
			}
			
		# Create an wiki table header
		$result = "=php bin search= \r\n";
		$result .= "{| class=\"wikitable\"\r\n|-\r\n! Detected path locations to an possible php bin \r\n";
		$result .= "! Result of the php execute test \r\n";
		$result .= "|+ Search for the PHP BIN executable inside the server \r\n";
		$result .= "|-\r\n";
		
		# fill the table with php bin search test results 
		foreach ($pout as $php_path){
			# Create an shell execute php command
			$cmd = "$php_path $IP/extensions/EUV/diagnostics/phpbinchk.php 2>&1";
			$result .= "|<nowiki>$php_path</nowiki> \r\n";
			# Execute the shell perform an php run command
			$a = shell_exec($cmd);
			# Chec if the php application is responding
			if ( strpos($a,"EUV-00001") ){ $a='<b><span style="color:green">'.$a.'</span></b>'; } 
				else { $a= "<b><span style='color:red'>error, location is not responding</span></b> ";}
			$result .= "|".$a." \r\n";
			$result .= "|- \r\n";
			}
			
		# The end of the tabel
		$result .= "|} \r\n";
		
		
		//print'possible paths :<pre>'; print_r( $pout ); print'</pre>';	
		//print'possible paths :<pre>'; print_r( $pout ); print'</pre>';		
		# Remove empty locations and sort them
		//$Shell_LS_Result = array_filter($Shell_LS_Result); rsort($Shell_LS_Result);
		# Seect only the filepath and file name that contain [/php]
		//foreach ($Raw_Result as $serverpath){if(strpos($serverpath,'/php') ){$php_locs[]=$serverpath;}}
		//print'<pre>'; print_r( $php_locs ); print'</pre>';
		//foreach ($php_locs as $serverpath)
		//		{
					//preg_match_all( "/ (.*?)\/php/si", $serverpath, $out, PREG_SET_ORDER );
					//preg_match_all( '# (.+?)/php#si', $php_locs, $out, PREG_SET_ORDER );
					//'#<body>(.+?)</body>#i'
		//		}
				
		//preg_match_all( '# (.+?)/php#si', $php_locs, $out, PREG_SET_ORDER );				
		//print'<pre>'; print_r( $Raw_Result ); print'</pre>';
		//$Shell_LS_Result = str_replace("\n"," ---------n------------",$Shell_LS_Result);
		//$aaa = preg_split('/\n/', $Shell_LS_Result, -1, PREG_SPLIT_OFFSET_CAPTURE);
		// print'<pre>'; print_r($paths); print'</pre>';
		// $paths[0][0] $paths[1][0]
		// foreach $paths ..... ls -l /share/MD0_DATA/.qpkg/Optware/var/lib/php
		// $output->addWikiText( $paths );
		
		return $result;
		
	}	
	
}
