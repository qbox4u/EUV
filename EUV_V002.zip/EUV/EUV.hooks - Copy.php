<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVHooks {
	
	/**
	 * Description
	 *
	 * @param $userId Integer
	 * @param $userPageTitle Title
	 * @param $toolLinks Array
	 *
	 * @return true
	 */
	public static function onParserFirstCallInit( Parser $parser ) {

		# Check the existance of the required EUV and EUV Diagnostics logging folder and create if they not exist
		$obj = new EUVLogging();
		$result = $obj->wf_EUV_CheckFilePaths();
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start onParserFirstCallInit");
		
		# Check the existance of the required default pages and add them if this is required
		EUVLogging::wf_EUV_DiagnosticsLogging('','onParserFirstCallInit call to $DefaultPages->wf_EUV_CreateDefaultPages()');
		
		# Activate the EUV Extension globals eg $wgEUVFuncCredits
		global $wgEUVFuncCredits;
		$obj = new EUVSetArrayGlobals();
		$dummy = $obj->wflist_wgEUVFuncinfo();
		
		//$DefaultPages = new EUVCreateDefaultPages();
		//$result = $DefaultPages->wf_EUV_CreateDefaultPages();
		
		// Set the hook <TAG> Hallo World </TAG>
		$parser->setHook( 'EUV', 'EUVTagBody::wf_EUV_TagFunctionRender' );
		
		// Set the hook {{#MyFirsthook:Hallo|World}}
		$parser->setFunctionHook( 'EUV', 'EUVParserBody::wf_EUV_ParserFunction_Render' );

		
    return true;
	
	}
	/**
	 * Description
	 *
	 * @param $userId Integer
	 * @param $userPageTitle Title
	 * @param $toolLinks Array
	 *
	 * @return true
	 */
	public static function onLanguageGetMagic( array &$magicWords, $langCode) {
		
		// Identify the hook {{#MyFirsthook:xxxxxxxxx}}
		// The first array element is whether to be case sensitive, in this case (0) it is not case sensitive, 1 would be sensitive
		
        $magicWords['EUV'] = array( 0, 'EUV' );
		
    # unless we return true, other parser functions extensions won't get loaded.
    return true;
	
	}

}
