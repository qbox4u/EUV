<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVFileFunctions {
	
		function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVFileFunctions'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVFileFunctions',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
		# The EUV extension Class info	
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVFileFunctions'] = array(
					'EUVfilename'           			=> 'EUVFileFunctions.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_ChkUserDir'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_ChkUserDir help page',
							'EUVphp_design_page'		=> 'wf_EUV_ChkUserDir design page',
						),	
						'wf_EUV_CreateRandomFilename'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_CreateRandomFilename help page',
							'EUVphp_design_page'		=> 'wf_EUV_CreateRandomFilename design page',
						),	
						'wf_EUV_ListZipArchive'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_ListZipArchive help page',
							'EUVphp_design_page'		=> 'wf_EUV_ListZipArchive design page',
						),
						'wf_EUV_ListAllfilenames'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_ListAllfilenames help page',
							'EUVphp_design_page'		=> 'wf_EUV_ListAllfilenames design page',
						),	
						'wf_EUV_GetFileIcon'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_GetFileIcon help page',
							'EUVphp_design_page'		=> 'wf_EUV_GetFileIcon design page',
						),	
						'wf_EUV_DispayAllFileIcons'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_DispayAllFileIcons help page',
							'EUVphp_design_page'		=> 'wf_EUV_DispayAllFileIcons design page',
						),						
					));
				
	}	
 
/**********************************
 * Class	: EUVDBase
 * ID		: wf_EUV_ChkUserDir()
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: Determines the presence of the directory availability for the output file.  
 *            in case the Directory folder is not present, the directory will be created   
 * Info		:  
 * Function	:  
 * Input	: $FolderName : required folder name
 *			  $FolderBasepath : Optional [ default = {$IP}/images ]
 *			   
 * Output	: Success ==>  True
 *	     	  Failure ==>  False
 * Error	:
 * Example	: new EUVFileFunctions();
 * 			  $obj->wf_EUV_ChkUserDir('pppp');  
 * 			  $obj->wf_EUV_ChkUserDir('pppp/ttttt');  
 * Implementation :   
 *  
 */	
 
 	public static function wf_EUV_ChkUserDir( $FolderName , $FolderBasepath  = 'images') { 
	
	    global 	$IP,
				$wgUploadDirectory, # {$IP}/images
				$wgUploadPath;		# {$wgScriptPath}/images
		
        # Assure the correct default Mediawiki EUV $FolderBasepath
		if ( $FolderBasepath == 'images' ){ $FolderBasepath = $IP."/images/EUV"; }
		
		# Assure an default directory
        if( $FolderName ) { 
		
			$result = false;
			$Destination_path = $FolderBasepath  . '/' . $FolderName;		

			# Check if the Directory folder is not present
			if( !is_dir( $Destination_path ) ) {
				
				# The folder is not present, so we need to create one
				# Default c  
				# Nested folders is allowed
				# mkdir 774 does not work !!!!!!
				mkdir( $Destination_path, 0777 , true );
				# Set the appropiate rights of the folder
				chmod($Destination_path, 0764);
			}
		
			# Check the actual access
			chdir($Destination_path);
			$dest = getcwd();
			if ( $dest == $Destination_path || $dest.'/' == $Destination_path  ){
				# Perform an file create, writen and read 
				$file 		= $Destination_path . '/' . 'wf_EUV_ChkUserDir.txt';
				$TestStr	= ' Write test';
				file_put_contents( $file, $TestStr );
				$ts = file_get_contents( $file );
				# Check the read write result
				if ( $ts == $TestStr ){
					# The read write result is the same
					# delete the test file					
					unlink( $file );
					$result = True ; 
					} 
					else {	# The read write result is not the same 						
							$result = False; }
				}
				else { # The $dest path differs from $Destination_path
						$result = False; }
		}
		else {	# no $FolderName is provided
				$result = False; }
		
    return $result ;
	
	}

/**********************************
 * Class	: EUVDBase
 * ID		: wf_EUV_CreateRandomFilename( $extension  = '')
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: Create an Random Filename 
 *             
 * Info		:  
 * Function	:  
 * Input	: $extension 	: Optional $extension [ default = '' ]
 *			   
 * Output	: Success ==>  True
 *	     	   
 * Error	:
 * Example	: 	$obj = new EUVFileFunctions();
 * 				$rnd_32 = $obj->wf_EUV_CreateRandomFilename(); 			CREATES 12d255713aa94d9d27a9f8ba7de60d2a
 * 				$rnd_32 = $obj->wf_EUV_CreateRandomFilename('.pdf'); 	CREATES dd4231b06827ff02ae3ef41e5c8e74b2.pdf 
 * Implementation :   
 *  
 */	
 
  	public static function wf_EUV_CreateRandomFilename( $extension  = '') { 

		# Random time
		list($usec, $sec) = explode(" ", microtime());
		$tim_dat 	= ((float)$usec + (float)$sec);
		# Random $pool
		$pool 		= '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$rnd_sub 	= substr(str_shuffle(str_repeat($pool, 16)), 0, 16);
		# Random pseudo bytes
		$rnd_hex 	= base64_encode(openssl_random_pseudo_bytes(30));
		# Random md5
		$rnd_md5 	= md5(uniqid(mt_rand(), true));
		# Add all strings together
		$datasrc 	= $tim_dat.$rnd_hex.$rnd_md5.$rnd_sub;
		# Create an nice 32-character hexadecimal md5 number
		$md5randata = md5($datasrc);
		# Add the extension to the 32 bit hexadecimal md5 number 
		$result 	= $md5randata.$extension;
		
	return $result;
	
	}
	
/**********************************
 * Class	: EUVDBase
 * ID		: wf_EUV_ListZipArchive($file)
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: List an Zip file archive 
 *             
 * Info		:  
 * Function	:  
 * Input	: $file 	: Zip file name
 *  		  $mode 	: Optional [ default = 'raw' ] => output an array
 *  		  $mode 	: Optional [ wiki ] => output an wiki table
 *			   
 * Output	: Success ==>  True
 *	     	   
 * Error	:
 * Example	: 	$obj 	= new EUVFileFunctions();
 *				$zips 	= $obj->wf_EUV_ListZipArchive( $file ) ; => output an array
 *				$wiki 	= $obj->wf_EUV_ListZipArchive( $file,'wiki') ; => output an wiki table
 * 				 
 * Implementation :   
 *  
 */		
 
	public static function wf_EUV_ListZipArchive( $file, $mode = 'raw' ) {
		
		$zip = new ZipArchive;
		$zips;
		if ( $zip->open( $file ) === TRUE ) {
			//iterate the archive files array and display the filename or each one
			# The header of the wiki table
			$wiki_table = "\n\r{|class='wikitable sortable mw-collapsible mw-collapsed ' style='white-space: nowrap; font-size: 90%; text-align:left;' width=80%  \n\r";
			$wiki_table .= "! item !! File name \n\r";
			$wiki_table .= "|+ ''' CLICK ON EXPAND TO VIEW THE ZIP FILES , OR ON COLLAPSE TO HIDE THE ZIP FILES''' \n\r";
			$wiki_table .= "|- \n\r";
			for ($i = 0; $i < $zip->numFiles; $i++) {
			if ( $mode == 'raw' ){ $zips[] =  $zip->getNameIndex($i); }
				else { $wiki_table .= "|$i ||" . $zip->getNameIndex($i) . " \n\r|- \n\r "; }
			}
			
			# The footer of the wiki table 
			$wiki_table .= "|} \n\r";
		
			# check what kind of output we require
			if ( $mode == 'raw' ){ $result = $zips; }
				else { $result = $wiki_table;}
		} 
		else { $result = '' ;}
			
	return $result;
	}
	
/**********************************
 * Class	: EUVDBase
 * ID		: wf_EUV_ListAllfilenames($file)
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: List all files inside an folder
 *             
 * Info		:  
 * Purpose  : Find RECURSIVE all files in an given folder INCLUDING ALL underlying SUBDIRECTORY'S
 *            and store these files in an array 
 * Input	: $file 	: sourse dir
 *			   
 * Output	: Success ==>  $result[]
 *	     	   
 * Error	:
 * Example	: 	$obj 			= new EUVFileFunctions();
 *  			$chkDirectory 	= '/share/MD0_DATA/Web/VHost_qbox4u/conf/tech/mwk/images';
 *           	$flist			= $obj -> wf_EUV_ListAllfilenames($chkDirectory);
 * 				 
 * Implementation :   
 *  
 */		
	public static function wf_EUV_ListAllfilenames($dir) {
			
			$a = self::wf_EUV_scan_folder($dir);
			# Remove the empty results from the array
			$emptyRemoved = array_filter( $a );
		
		return $emptyRemoved; 
		
	}	
	# WARNING NESTED RECURSIVE FUNCTIONS TO PERFORM MULTY LEVEL CHECKS
	public static function  wf_EUV_scan_folder($dir) {
		
			$result;
			# get the folder items
			$root = scandir($dir); 
			
			foreach($root as $value){ 

				if( count( $root ) === 2  ) 				{ $result[] = ''; continue; }
				if( $value === '.' || $value === '..' ) 	{ continue; } 

				// WARNING NESTED RECURSIVE FUNCTIONS TO PERFORM MULTY LEVEL CHECKS
				if( is_file("$dir/$value") ) { $result[] = "$dir/$value"; continue; } 

				foreach( self::wf_EUV_ListAllfilenames("$dir/$value" ) as $value) { 
					$result[] = "$value" ;
					} 
			} 
			# assure we have an valid return array
			if( !isset($result)){ $result[] =''; }
		
		return $result; 
	} 
	
/**********************************
 * Class	: EUVDBase
 * ID		: wf_EUV_GetFileIcon($file)
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *             
 * Info		: Uses the icon library file_extension_icons_32x32 
 * Purpose  : Select an correct file ICON that belongs to an given file
 *             
 * Input	: $file 	: sourse file
 *			  $size 	: Optional [ default = 32px ] 
 * Output	: Success ==>  $result
 *	     	   
 * Error	:
 * Example	: 	$obj 		= new EUVFileFunctions();
 * 				$filename 	= __FILE__;
 * 				$ficon		= $obj -> wf_EUV_GetFileIcon( $filename );
 * 				$output->addWikiText( $ficon  ) ;
 *				$ficon		= $obj -> wf_EUV_GetFileIcon( $filename,16 );
 * 				$output->addWikiText( $ficon  ) ;
 * 				 
 * Implementation :   
 *  
 */		
 
 	public static function wf_EUV_GetFileIcon($filename, $iconsize = 32 ) {
				
				# Filter the extension out of the $filename
				$ext = pathinfo($filename, PATHINFO_EXTENSION);
				# Assure we use lower case
				$ext = strtolower($ext);
				# Create an correct file icon name
				$file_extension_icon = "File_extension_icon_32px_".$ext.".png";
				# Select the required size of the icon
				$WikiFileIcon = "[[File:$file_extension_icon|".$iconsize."px]]";
				
		return $WikiFileIcon;
		
	}
/**********************************
 * Class	: EUVDBase
 * ID		: wf_EUV_DispayAllFileIcons()
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *             
 * Info		: Uses the icon library file_extension_icons_32x32 
 * Purpose  : Dispay the availability of all file extension icons
 *             
 * Input	:  none 
 *			   
 * Output	: Success ==>  $result
 *	     	   
 * Error	:
 * Example	: 	$obj 		= new EUVFileFunctions();
 * 				$ficons		= $obj -> wf_EUV_DispayAllFileIcons();
 * 				$output->addWikiText( $ficons  ) ;
 * 				 
 * Implementation :   
 *  
 */	

 	public static function wf_EUV_DispayAllFileIcons() {
		
			$iconfiles;
			$chkDirectory 		= '/share/MD0_DATA/Web/VHost_qbox4u/conf/tech/mwk/images';
			$flist				= self::wf_EUV_ListAllfilenames($chkDirectory);

			$sword 				= 'File_extension_icon_32px';
			$matches 			= preg_grep ("/\b($sword\w+)\b/", $flist );

			# remove unwanted items
			$sword 				= "\/thumb\/";
			$matches_cleaned 	= preg_grep ("/^((?!$sword).)*$/", $matches  );

			if( count( $matches_cleaned) > 100 ){
				foreach ( $matches_cleaned as $path ) { $iconfiles[] = basename($path); }
				# sort the file names
				asort ( $iconfiles ,SORT_REGULAR );
				# The header of the wiki table
				$wiki_table = "{|class='wikitable' style='white-space: nowrap; font-size: 90%; text-align:center;'  \n\r";
				//$wiki_table .= "!icon !! icon  \n\r";
				$wiki_table .= "|+ ''' Avaiable File extension icons''' \n\r";
				$wiki_table .= "|- \n\r";
				$i = 0;
				foreach ( $iconfiles as $file) {
					$i++;
					$getName	= strtoupper( explode(".",explode("_",$file)[4])[0]);
					$wiki_table .= "| [[File:$file]]''' <br><b> $getName </b>''' \n\r ";	
					if ( $i > 9 ){ $i =0; $wiki_table .= "|- \n\r" ;}
				}	
				# The footer of the wiki table 
				$wiki_table .= "|} \n\r";

			}
			else{ $wiki_table = " ERROR, Not enough icons available";}
	
		return $wiki_table;
		
	}	
	
}
