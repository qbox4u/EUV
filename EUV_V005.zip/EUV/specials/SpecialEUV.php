<?php
 /******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */


class SpecialEUV extends SpecialPage {
	
	
	public function __construct() {
		
		parent::__construct( 'EUVAdmin' );

		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['SpecialEUV'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class SpecialEUV',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info		
		global 	$wgEUVFuncinfo;	
				$wgEUVFuncinfo['SpecialEUV'] = array(
					'EUVfilename'           				=> 'SpecialEUV.php',
					'EUVfunctions'							=> array( 
						'execute'							=> array(
							'EUVhelp_page'						=> 'execute help page',
							'EUVphp_design_page'				=> 'execute design page',
						),
						'wf_EUV_SpecialPageRadioButtonCheck'=> array(
							'EUVhelp_page'						=> 'wf_EUV_SpecialPageRadioButtonCheck help page',
							'EUVphp_design_page'				=> 'wf_EUV_SpecialPageRadioButtonCheck design page',
						),					
					));	
	}				
				
const B_TagTest = <<<QBoxFSP

{|class="wikitable mw-collapsible mw-collapsed" style="white-space: nowrap;font-size:12px;"
|style='background:#ffdead;' | ''' CLICK ON EXPAND TO VIEW THE TAG TEST, OR ON COLLAPSE TO HIDE THE TEST'''
|-
|

====Tags====
{|class="wikitable" style="white-space: nowrap;font-size:12px;"text-align:left;" width=80%
| style="text-align:left;"|'''TEST <nowiki><EUV const1=aaa const2=bbbb> Hallo World </EUV></nowiki>'''
|- style="vertical-align: top;"
|
 <nowiki><EUV const1=aaa const2=bbbb> Hallo World </EUV></nowiki>
<EUV const1=aaa const2=bbbb> Hallo World </EUV>
|}

{|class="wikitable" style="white-space: nowrap;font-size:12px;" width=80%
| style="text-align:left;"|'''TEST <nowiki>{{#EUV:help|Hallo|World}}</nowiki></nowiki>'''
|- style="vertical-align: top;"
|
 <nowiki>{{#EUV:help|Hallo|World}}</nowiki>
{{#EUV:help|Hallo|World}}
|}

|}

QBoxFSP;

	/**
	 * Show the page to the user
	 *
	 * @param string $sub The subpage string argument (if any).
	 *  [[Special:HelloWorld/subpage]].
	 */

/**********************************
 * Class	: SpecialEUV
 * ID		: execute( $par )
 * Release	: NA 
 * Date		: Created 26-10-2016 by JBoe
 * Notes	: Impementation of the EUV SpecialEUV page
 *
 * Purpose	: To retrieve the parameters used inside the TAG
 * Info		: 	
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	 
	function execute( $par ) {
		
		global $wgUser,$wgEUV_QBox_PHPBin,$B_TestPage,$wgScriptPath,$wgEuvUserconfig_json,$IP,$wgDBname;
			
		$output = $this->getOutput();
		$output->setPageTitle( $this->msg( 'euv-helloworld' ) );
		
		$request = $this->getRequest();
		$this->setHeaders();
		
		$EUV_Welcome_ContactPage = <<<EUVCO
{| width=100%
|-
|
 [[Special:Contact|'''CONTACT''']] the designer of this QBox4U EUV extension regarding suggestions 
 press the envelope [[File:Mail-send.png|50px|link=Special:Contact]] or email directly to qbox4u@gmail.com
 [[File:Linkedinrebound.png|link=https://www.linkedin.com/in/jan-boer-a24640113]]
 |[[File:Admin_icon_03.png|200px|center|link=EUV Admin Work in process|EUV Admin Work in process]] 
|}

EUVCO;

		$ExternalProjectLinks_Table = <<<A_Table
{|class="wikitable" style="white-space: nowrap;font-size:12px;" 
! EXTERNAL PAGE !! EXTERNAL LINK
|+ ''' Update your external project pages'''
|- style="vertical-align: top;"
|EUV extension design page||[[Create_EUV_extension]]
|- 
|EUV '''Mediawiki page'''||[https://www.mediawiki.org/wiki/Extension:EUV Extension:EUV]
|- 
|EUV '''GitHub page'''||[https://github.com/qbox4u/EUV qbox4u EUV]
|}

A_Table;

		# ...Add the base instructions from mediawiki
		$output->addHelpLink( 'Extension:EUV' );
		
		# ...Add the admin page form name 
		$output->addHTML("<form action='' method='post' id='Special_EUVAdmin_page'>");
		
		# ...User name
		$a = $wgUser->getName();
		# ...Messages		
		$SpecialPageinfo = "Hello user:$a !<br>";
		
		$SpecialPageinfo .= $this->msg( 'euv-welcome' )->parse().'<br>';		
		$output->addWikiText( $SpecialPageinfo );
		$output->addWikiText( $EUV_Welcome_ContactPage );
		$output->addWikiText( $ExternalProjectLinks_Table );		
		
		# ...Create an Special Administrator functions menu
		$AdminFuncLinks_Table = <<<AF_Table
{|class="wikitable" style="text-align:left;"
! Activate!! Function
|+ ''' Special Administrator functions'''
|- 
| style="text-align:center;"|[[File:system-run-5.png|25px|link={{canonicalurl:{{FULLPAGENAME}}|func=ob_start}}|press me to check if ob_start works]] ||Check if ob_start works
|- 
| style="text-align:center;"|[[File:system-run-5.png|25px|link={{canonicalurl:{{FULLPAGENAME}}|func=db_backup}}|press me to Backup MySQL]] || Backup MySQL
|- 
| style="text-align:center;"|[[File:system-run-5.png|25px|link={{canonicalurl:{{FULLPAGENAME}}|func=db_dmysqlbackups}}|press me to display all MySQL Backups]] || Display all MySQL Backups
|- 
| style="text-align:center;"|[[File:system-run-5.png|25px|link={{canonicalurl:{{FULLPAGENAME}}|func=xxxxxxxx}}|press me to activate xxxxxxxx]] ||new function
|}
AF_Table;

		$output->addWikiText( $AdminFuncLinks_Table );
		# ...Retrieve the page Globals 
		if ( isset( $_REQUEST['func'] ) ) { $func = preg_replace('/[^A-Za-z0-9_]/','',$_REQUEST['func']); } 		else { $func	= '';}
		if ( isset( $_REQUEST['minf'] ) ) { $minf = preg_replace('/[^A-Za-z0-9_]/','',$_REQUEST['minf']); } 		else { $minf	= '';}
		if ( isset( $_REQUEST['stat'] ) ) { $stat = preg_replace('/[^A-Za-z0-9_]/','',$_REQUEST['stat']); } 		else { $stat	= '';}	
		
		# Execute the required Administrator function ( if any is pressed )
		switch ($func) { 

			case '':					$output->addWikiText("\r No Special Administrator functions selected");	break;
			case 'db_dmysqlbackups':	$obj=	new EUVDBaseMySQLBackup(); 
												$result_info = $obj->wf_EUV_DisplayAllMySQLBackups();
												$output->addWikiText($result_info);	
												break;
			case 'db_backup':			$obj=	new EUVDBaseMySQLBackup(); 
												$result_info = $obj->wf_EUV_MySQL_Backup($wgDBname);
												$output->addWikiText(" The new MySQL_Backup \n \n <code>".$result_info.'</code>');	
												break;
			case 'ob_start':			$obj=	new EUVtestob_start(); $result_info = $obj->wf_EUV_Wikipages_ob_start(); 	break;
		
			default: 					$output->addWikiText("<span style='color:red'>Error:</span> Special function $func DOES NOT EXIST");
		}
		
			
		$output->addWikiText("=Automatic Design and setup Functions= \r\n");
		
		

		
		
 
		# Test: *****************************************
		# show the Logging files
		$output->addWikiText("=== Display the last 10 EUV Diagnostics Logging Files  === \r\n");
		# Check if we need to modify $wgEuvUserconfig_json['config']['EUVDispayLoggingfiles']
		# wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$page_output )
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVDispayLoggingfiles','EUVDispayLoggingfiles',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$obj = new EUVDispayLoggingfiles();
			$result = $obj->wf_EUV_DispayLoggingfiles();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Sdlf' )->parse() );}				
		
		# Test: *****************************************
		# show the TAG test
		$output->addWikiText("===Testing the TAG functionality=== \r\n");
		# Check if we need to modify $wgEuvUserconfig_json['config']['EUVDispayTestTag']
		# wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$page_output )
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVDispayTestTag','EUVDispayTestTag',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$output->addWikiText( self::B_TagTest );}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Sdtt' )->parse() );}		
		
		# Test: *****************************************
		# Check the bin location and create an wiki table
		$output->addWikiText("=== QBox qnap server php bin executable search === \r\n");
		# Check if we need to modify $wgEuvUserconfig_json['config']['EUVphpbinchk']
		# wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$page_output )
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVphpbinchk','EUVphpbinchk',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$obj = new EUVphpbinchk();			
			$result = $obj->wf_EUV_phpBinlocationCheck();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Spbs' )->parse()."<code>$wgEUV_QBox_PHPBin</code>");}		
	
		# Test: *****************************************
		# import the default EUV images
		$output->addWikiText("===Import default images===  \r\n");
		# Check if we need to modify $wgEuvUserconfig_json['config']['EUVphpbinchk']
		# wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$page_output )
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVImportImages','EUVImportImages',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$obj = new EUVImportImages();
			$result = $obj->wf_EUV_ImportDefaultImages();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Sidi' )->parse() );}	

		# Test: *****************************************
		# Check and create the default wiki pages
		$output->addWikiText("=== Create and Update default EUV Pages===  \r\n");
		# Check if we need to modify $wgEuvUserconfig_json['config']['EUVphpbinchk']
		# wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$page_output )
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVCreateDefaultPages','EUVCreateDefaultPages',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$DefaultPages = new EUVCreateDefaultPages();
			$result = $DefaultPages->wf_EUV_CreateDefaultPages();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Slfd' )->parse() );}	
					
		# Test: *****************************************
		# Create an table with the presently used classes and functions information
		$output->addWikiText("===Classes and functions information=== \r\n");
		# Check if we need to modify $wgEuvUserconfig_json['config']['EUVphpbinchk']
		# wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$page_output )
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVFuncinfo','EUVFuncinfo',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			//global $wgEUVFuncCredits;
			$obj = new EUVSetArrayGlobals();
			$result = $obj->wf_EUV_list_wgEUVFuncinfo();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Scfi' )->parse() );}	

		# Test: *****************************************
		# Test lantronix UDS1100
		$output->addWikiText("===Test lantronix UDS1100 functionality===  \r\n");
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVlantronix','EUVlantronix',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$obj = new EUVlantronix();
			$result = $obj->wf_EUV_Test_UDS1100();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Stla' )->parse() );}						

					
		# Test: ***********************
		# Test FTP functionality
		$output->addWikiText("===Testing FTP functionality===  \r\n");
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVTestPftp','EUVTestPftp',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			$obj = new EUVftp();
			$result = $obj->wf_EUV_ftpCheck();
			$output->addWikiText($result);}
				else { 
					#The test function is disabled		
					$output->addWikiText( $this->msg( 'euv-Sftd' )->parse() );}	
					
		
		# Test: ***********************	
		$output->addWikiText("===Testing Mail-send functionality===  \r\n");
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVTestMail','EUVTestMail',$output );	
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){		
			$obj = new EUVSendmail();
			
			$output->addWikiText(' Sending html mail to qbox4u@gmail.com');
			$to = 'qbox4u@gmail.com';
			$result = $obj->wf_EUV_Send_Email('html',$to,'html test 1 ','<h1>Please delete this mail!</h1>');
			$output->addWikiText(' Result of email:'.$result.' < 1 means mail has been send >');
			
			$output->addWikiText(' Sending plain mail to qbox4u@gmail.com');
			$to = 'qbox4u@gmail.com';
			$result = $obj->wf_EUV_Send_Email('plain',$to,'plain 1',"sorry....this is an test\nPlease delete this mail\n");
			$output->addWikiText(' Result of email:'.$result.' < 1 means mail has been send>');}
				else { 
					#The send mail test function is disabled	
					$output->addWikiText( $this->msg( 'euv-Smad' )->parse() );}	

					

		# Test: *****************************************
		# Display the available File Icons
		$output->addWikiText("===Display File Icons===  \r\n");
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVDiFileIcons','EUVDiFileIcons',$output );
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$obj 		= new EUVFileFunctions();
			$ficons		= $obj -> wf_EUV_DispayAllFileIcons();
			$output->addWikiText($ficons) ;}	
			else { 
				#The test function is disabled		
				$output->addWikiText( $this->msg( 'euv-Sfig' )->parse() );}
 		# Test: *****************************************						
					
					
			
					
		# Test: ***********    LAST !!!!!!!! ************
		# ...Display Globals wgEuvUserconfig_json 
		$output->addWikiText("===Display Globals wgEuvUserconfig_json===  \r\n");
		$t_status = self::wf_EUV_SpecialPageRadioButtonCheck( 'EUVDiGloEuvUserconfigjson','EUVDiGloEuvUserconfigjson',$output );
		# Output into the EUV Administrator page the correct TEST information
		if ( $t_status == 'Activated'){ 
			# The test function is active
			$obj = new EUVDBaseDisplayLibrary();
			$result = $obj->wf_EUV_Display_Globals_wgEuvUserconfig_json();
			$output->addWikiText($result);}	
			else { 
				#The test function is disabled		
				$output->addWikiText( $this->msg( 'euv-Sdug' )->parse() );}
		# Test: *****************************************
	
		# ...Add the end of the admin page name 
		# anything between the 2 <form> xxxx </form> tags will be an $_REQUEST item
		$output->addHTML("</form>");
		
	}

	protected function getGroupName() {
		return 'other';
	}

/**********************************
 * Class	: SpecialEUV
 * ID		: wf_EUV_SpecialPageRadioButtonCheck
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of the EUV SpecialEUV page
 *
 * Purpose	:  
 * Info		: 	
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
		public static function wf_EUV_SpecialPageRadioButtonCheck( $RB_REQUEST,$json_item,$P_output ) { 
		
			global $wgEuvUserconfig_json,$wgEUV_UserconfigurationFile;
			
				$status ='';
				# Check if we need to modify the global $wgEuvUserconfig_json['EUVSpecialPageRadioButton']['< the test item >']
				if( isset($_REQUEST[$RB_REQUEST]) && $_REQUEST[$RB_REQUEST] != "" ){
						# Yes, we probably need to adapt the new setting into the DB
						$status = $wgEuvUserconfig_json['EUVSpecialPageRadioButton'][$json_item];
						$newp 	= $_REQUEST[$RB_REQUEST]; 
						$oldp 	= $wgEuvUserconfig_json['EUVSpecialPageRadioButton'][$json_item];
						if( $newp !== $oldp ){ 
							# The new radio button differs from the configuration.
							# Adapt this new setting inside the global $wgEuvUserconfig_json
							$wgEuvUserconfig_json['EUVSpecialPageRadioButton'][$json_item] = $newp; 
							
							# Adapt this new setting inside the DB
							$obj = new EUVDBaseCreateDefaultTables();
							$tmp = $obj->wf_EUV_DBUpdate_jsonRecords('EUVSpecialPageRadioButton',$json_item,$newp);

							# Remove the update request of the EUVphpbinchk radio button
							$status = $wgEuvUserconfig_json['EUVSpecialPageRadioButton'][$json_item];
							unset($_REQUEST[$RB_REQUEST]);}
						else{ 
							$status = $wgEuvUserconfig_json['EUVSpecialPageRadioButton'][$json_item];}	
					}
				
				# Prepare the HTML Radiobutton setting to visualise the status
				$status = $wgEuvUserconfig_json['EUVSpecialPageRadioButton'][$json_item];
				if ( $status == 'Activated'){ /* The test function is active */ $tfa='checked'; $tfd='';} 
					else { /* The test function is disabled */ $tfa=''; $tfd='checked';}	
					
				# Create the required dedicated java function to update the radio buttons inside userconfig.json
				$P_output->addHTML("<script type='text/javascript'>function handle".$json_item."Click( myRadio ) { document.getElementById('Special_EUVAdmin_page').submit(); } </script> ");
				# Create the 2 required function radio buttons 
				$P_output->addHTML("This function is :<input type='radio' name='$json_item' title='Any change will reload the page again' onchange='handle".$json_item."Click(this)'; value='Activated' $tfa> Activated \r\n");
				$P_output->addHTML("<input type='radio' name='$json_item' title='Any change will reload the page again' onchange='handle".$json_item."Click(this)'; value='Disabled' $tfd > Disabled");
		
		return $status;
		
		}
	
}
