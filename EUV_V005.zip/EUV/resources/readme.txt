DO NOT USE IMAGES WITH THE TEXT

* Warning
* Failed
* Error
* suitable
* Could not open