<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

/**********************************
 * Class	:  
 * ID		:  
 * Release	: NA 
 * Date		: Created 26-10-2016 by JBoe
 * Notes	: Impementation of  
 *
 * Purpose	: To retrieve blablabla
 * Info		: 	
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	 
class EUVtestob_start extends ArrayObject{

	public static function  wf_EUV_Wikipages_ob_start(){

		# Set the maximum duration of the function
		ini_set('max_execution_time', 20);
 
		$pageContent = '<br>start plain test wf_EUV_Wikipages_ob_start()<br>';
		# List the active headers that are already available
		if( headers_list()){
			foreach (headers_list() as $header){
				$pageContent .= "<br>avaiabe headers $header before wf_EUV_Wikipages_ob_start() --";
			}
			$pageContent .= '<br><br>' ;
		}
  
		$pageContent .= 'Checking Content-Encoding = ' . ini_get('Content-Encoding') . '<br>';

		if (ob_get_level()) { $prHTM =ob_get_contents(); $pageContent .= "found ob_get_level a:".ob_end_clean()." previous buffer content:$prHTM length:".strlen($prHTM)."<br><br>"; }
		if (ob_get_level()) { $prHTM =ob_get_contents(); $pageContent .= "found ob_get_level b:".ob_end_clean()." previous buffer content:$prHTM length:".strlen($prHTM)."<br><br>"; }
		if (ob_get_level()) { $prHTM =ob_get_contents(); $pageContent .= "found ob_get_level c:".ob_end_clean()." previous buffer content:$prHTM length:".strlen($prHTM)."<br><br>"; }
		if (!headers_sent()) { 	$pageContent .= 'Previousy, no headers were send inside wf_EUV_Wikipages_ob_start()<br>';
								$pageContent .= "sending now header('Content-Encoding: none')<br>";
								$pageContent .= "sending now dynamically  data to screen <br><br>";

					    		header('Content-Encoding: none'); //disable apache compressed
								} 
					else { $pageContent .= 'already headers send'; }

					# Start the real time HTML output
		ob_start();

		echo $pageContent;

		for( $i= 0 ; $i <= 10 ; $i++ ){
    		print 'Test:'.$i."<img src='https://qbox4u.com:8081/conf/tech/mwk/images/9/92/Active_Yes.png'>\n\r <br>";
			
    		ob_flush();
    		# This is the buffer minimum size in order to flush data in IE and Chrome
			print str_pad('', 1024*8). "\r";
    		sleep(1);
		}
		
		if (headers_sent()) {
			foreach (headers_list() as $header){
				echo "<br>test is now finished --headers $header were avaiable after wf_EUV_Wikipages_ob_start() finished--";
			}
  		echo "<br><br>";
		}
		
		
		print "<br>wf_EUV_Wikipages_ob_start test is now finished. ob_end_flush() <br>";

		# You are not able to return to the QBox wiki, so choose one of the possible endings
		# 
		print' We will close this window in 5 seconds';
		print'<script type="text/javascript">setTimeout(function(){ window.close(); }, 5000); </script>';
		//print' We redirect you to https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Special:EUVAdmin<br>';
		//print'<script type="text/javascript">window.location.href = "https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Special:EUVAdmin";</script>';
		#

		
		print str_pad('', 1024*8). "\r";
		$html=ob_end_flush();
		echo "<br>ob_end_flush() result is:--$html--<br>";

		sleep(5);

		$result_info =  "<br>plain test finished....<br>";
		$result_info = '';

		return $result_info;
	}

			
		
		
	}
