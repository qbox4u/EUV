<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVDBaseDisplayLibrary {

	function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVDBaseDisplayLibrary'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVDBaseDisplayLibrary',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
		# The EUV extension Class info	
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVDBaseDisplayLibrary'] = array(
					'EUVfilename'           			=> 'EUVDBaseCreateDefaultTables.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_Display_Globals_wgEuvUserconfig_json'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_Display_Globals_wgEuvUserconfig_json help page',
							'EUVphp_design_page'		=> 'wf_EUV_Display_Globals_wgEuvUserconfig_json design page',
						),	
					));
				
	}	
	

/**********************************
 * Class	: EUVDBaseDisplayLibrary
 * ID		: wf_EUV_Display_Globals_wgEuvUserconfig_json
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
 
	function wf_EUV_Display_Globals_wgEuvUserconfig_json(){
		
		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname,$wgDBprefix;
		
		$Local_TableTop = <<<ELTT

{| class="wikitable sortable" border="1" cellpadding="0" cellspacing="0" style="font-size: 80%;"
|+ <span style = "color:blue">Display Global parameters status &#36;wgEuvUserconfig_json</span>
|-
!item<br>
!Database Table [[image:System-help.png|16px|link= EUV Help wgEuvUserconfig_json Table]]  	
!Parameter [[image:System-help.png|16px|link= EUV Help wgEuvUserconfig_json Table]]	
!Global [[image:System-help.png|16px|link= EUV Help wgEuvUserconfig_json Table]]
!Status [[image:System-help.png|16px|link= EUV Help wgEuvUserconfig_json Table]] 	
|-

ELTT;


		$Local_TableBottom = <<<ELTB
|}

ELTB;

		$func_result = '';
		$Wiki_result = '';
		
		$db_select_obj = mysqli_connect( $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname);
		if ( !$db_select_obj == null ){
			
			mysqli_set_charset($db_select_obj, "UTF8");
			
			# First retrieve the table that contains to the required Userconfig_json table(s)
			$tnam = $wgDBprefix.'EUVuserconfigVersions';
			EUVLogging::wf_EUV_DiagnosticsLogging('',"Retrieve the DB Table $tnam");	
		
			$query 	= "SELECT * FROM $tnam ";
			$result = mysqli_query($db_select_obj,$query) or trigger_error("mysqli_query - Error: ". mysqli_error($db_select_obj), E_USER_ERROR);
			$table_array = $result->fetch_assoc();
			$reqTables;
			# put the table names into an array
			# The key is the text EUV inside the name
			foreach ( $table_array as $EUVTableKey => $value ){ 
					if( strpos( $EUVTableKey,"EUV" )> -1 ) { 
						$reqTables[] = $EUVTableKey; 
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Found an EUVTableKey request for $EUVTableKey");
						}
			}
			$i = 0;
			# Now retrieve the identified table(s)
			$Userconfig_json;
			foreach ( $reqTables as $EUVTableKey  ){
				$tnam = $wgDBprefix.$EUVTableKey;
				$query 	= "SELECT * FROM $tnam ";
			    $result = mysqli_query($db_select_obj,$query) or trigger_error("mysqli_query - Error: ". mysqli_error($db_select_obj), E_USER_ERROR);
				$data = $result->fetch_assoc();
				foreach ( $data as $key =>$value  ){
					$i++;
					$Wiki_result .= "|$i ||$tnam || $key || wg$key || $value  \n\r|-"."\n\r";
				}
			}
			
			$dbclosing = mysqli_close($db_select_obj) or trigger_error("SQL closing - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			if($dbclosing) { $func_result = $table_array; } else { $func_result = false; }
		}
		
		#Combine the result table with an mw-collapsible table
		$html_result = '';
		$html_result .= '{|class="wikitable sortable mw-collapsible mw-collapsed" style="white-space: nowrap;font-size:12px;" '."\r\n";
		$html_result .= "|style='background:#ffdead;' | ''' Global parameters status &#36;wgEuvUserconfig_json ''' "."\r\n";
		$html_result .= "|- \r\n| \r\n";
		
		$html_result .= $Local_TableTop.$Wiki_result.$Local_TableBottom;
		
		$html_result .= "|}"."\r\n";

		$result = $html_result;

	return $result;

	}
	
}
