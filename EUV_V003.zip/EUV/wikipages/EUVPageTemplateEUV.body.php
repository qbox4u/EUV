<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

 
class EUVPageTemplateEUV extends ArrayObject{

public  $TemplateEUV;

	public function __construct($T_array) {
		parent::__construct($T_array,ArrayObject::ARRAY_AS_PROPS);

		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVPageTemplateEUV'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVPageTemplateEUV',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info		
		global 	$wgEUVFuncinfo;	
				$wgEUVFuncinfo['EUVPageTemplateEUV'] = array(
					'EUVfilename'           			=> 'EUVPageTemplateEUV.body.php',
					'EUVfunctions'						=> array( 
						'EUV_PageTemplate_TemplateEUV'	=> array(
							'EUVhelp_page'				=> 'EUV_PageTemplate_TemplateEUV help page',
							'EUVphp_design_page'		=> 'EUV_PageTemplate_TemplateEUV design page',
						),						
					));		
					
/**********************************
 * Class	: EUVTemplateEUV
 * Release	: V1.0 
 * Date		: Created 30-10-2016 by JBoe
 * Notes	: Impementation of QBox EUV WIKI Pages
 *
 * Purpose	: Create an QBox Wiki template page with variables 
 * Info		:  
 * Function	: Inject parameters into an Wiki page template 
 * Input	: $T_array
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	: 	$Page_inject 	= array('p1'=>'10','p2'=>'20','p3'=>'30','p4'=>'30','p5'=>'30'); 
				$obj 			= new EUVPageTemplateEUV($Page_inject);
				$page 			= $obj->TemplateEUV;
				print $page .'<br>';
				print '<pre>';print_r($obj);print '</pre>'
 *			  
 * Implementation :   
 *  
 */		
# This is the RAW QBox Wiki page definition
# All variables need to be created and/or updated and inserted into the page before returning the page

		$EUV_PageTemplate_TemplateEUV = <<<QBoxPT1
{|style="font-size:100%"
| [[Image:EUV_04.png|90px|left|link=Category:QBox_EUV]]
|QBox EUV Information template: 
'''This page contains EUV information'''<br>
<categorytree mode=pages depth=0>Category:QBox_EUV</categorytree>
|}<includeonly>
{{#ifeq:{{FULLPAGENAME}}|Template:EUV||{{#ifeq:{{FULLPAGENAME}}|Category:QBox template||[[Category:QBox_EUV]]}}}}</includeonly><noinclude>
== Use ==
*Add '''<nowiki>{{EUV}}</nowiki> ''' 
To any page that contains QBox EUV information related data
 
[[Category:QBox_template]]
</noinclude>

QBoxPT1;
	
		$this->TemplateEUV = $EUV_PageTemplate_TemplateEUV ;

	}	
	
}
