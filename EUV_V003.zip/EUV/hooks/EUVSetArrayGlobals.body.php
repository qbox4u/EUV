<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */
 
class EUVSetArrayGlobals extends ArrayObject{

	function __construct(){
		
		# Create the user configuration allocated inside $wgUserconfigurationFile
		# The file name is identified inside extension.json at "config"
		global 	$wgEUV_UserconfigurationFile,$wgEUV_UserconfigurationDefaultFile,$wgEuvUserconfig_json;
		
				# The Userconfig_json table(s) check
				EUVLogging::wf_EUV_DiagnosticsLogging('F',"****** start EUVSetArrayGlobals function from database __construct");
				$obj = new EUVDBaseCreateDefaultTables();
				$tables_available = $obj->wf_EUV_Check_ValidDBUserconfig_json();
				
				# Check if all required Userconfig_json table(s) are present, otherwise create new table(s)
				if(!$tables_available){ 
					# Not all required Userconfig_json table(s) are present
					EUVLogging::wf_EUV_DiagnosticsLogging('',"<span style='color:red'>we have missing table(s). Create therefore new DB table(s)</span>");
					$result = $obj->wf_EUV_Create_Default_Tables(); }					
					
				# Retrieve all Userconfig_json parameters out of the database
				$Userconfig_jsontable_array = $obj->wf_EUV_DBReadUserconfig_jsonRecords();
				$wgEuvUserconfig_json = $Userconfig_jsontable_array;				
			
				EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End EUVSetArrayGlobals function from database __construct");
			
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVSetArrayGlobals'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVSetArrayGlobals',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info
		global	$wgEUVFuncinfo;	
				$wgEUVFuncinfo['EUVSetArrayGlobals'] = array(
					'EUVfilename'           		=> 'EUVSetArrayGlobals.body.php',
					'EUVfunctions'					=> array( 
						'wf_EUV_list_wgEUVFuncinfo'	=> array(
							'EUVhelp_page'			=> 'wf_EUV_list_wgEUVFuncinfo help page',
							'EUVphp_design_page'	=> 'wf_EUV_list_wgEUVFuncinfo design page',
						),
						'Get wgEUV_UserconfigurationFile'			=> array(
							'EUVhelp_page'			=> 'wgEuvUserconfig_json create help page',
							'EUVphp_design_page'	=> 'wgEuvUserconfig_json create design page',
						),
					));

	}	

/**********************************
 * Class	: EUVSetArrayGlobals
 * ID		: wf_EUV_list_wgEUVFuncinfo()
 * Release	: NA 
 * Date		: Created 08-11-2016 by JBoe
 * Notes	:  
 *
 * Purpose	: List the used Classes and wf functions 
 * Info		: 
 * Function	:   
 * Input	:   	
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_list_wgEUVFuncinfo(){
		
		global $wgEUVFuncinfo;	

			# Create an wiki table header to inject the actual used classes and functions 
			$result = "";
			$result .= "{|class='wikitable sortable' \r\n";
			$result .= "|+ Presently used EUV classes and functions information \r\n";			
			$result .= "|-\r\n";
			$result .= "! Class !! Filename !! Function name !! Help page !! Design info page \r\n";
			$result .= "|-\r\n";
			
			# Create the wiki table colom's with the relevant class information
			foreach($wgEUVFuncinfo as $class => $classinfo ){
				foreach( $classinfo['EUVfunctions'] as $Functions => $FunctionName ){
					# Create an wiki table colom with the relevant information
					# Wiki table Class !!           Filename          !!Function name !!         Help page               !!               Design info page
					$result .= "|$class||".$classinfo['EUVfilename']."||$Functions    ||[[".$FunctionName['EUVhelp_page']."]]||[[".$FunctionName['EUVphp_design_page']."]] \r\n|-\r\n";
				}
			}
			
			# Close the wiki table  
			$result .= '|}';
			
			# Create an sub header in the listing  
			$html_result = "=Global &#36;wgEUVFuncinfo = \r\n";
			# Create an wiki header to Hide and expand display the wiki table as stored inside $result 
			$html_result .= '{|class="wikitable mw-collapsible mw-collapsed" style="white-space: nowrap;font-size:12px;" '."\r\n";
			$html_result .= "|style='background:#ffdead;' | ''' CLICK ON EXPAND TO VIEW THE INFO, OR ON COLLAPSE TO HIDE THE TEST''' "."\r\n";
			$html_result .= "|- \r\n| \r\n";
			# Inject into this Expandable wiki table the listing
			$html_result .= $result;
			# close the Expandable wiki table 
			$html_result .= "\r\n".'|}'."\r\n";
			
		return $html_result;
		
	}
  
		
	}
