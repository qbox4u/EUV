<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVImportImages {
	
	function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVParserBody'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVParserBody',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info			
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVImportImages'] = array(
				'EUVfilename'           			=> '/images/EUVImportImages.body.php',
				'EUVfunctions'						=> array( 
					'wf_EUV_ImportDefaultImages'	=> array(
						'EUVhelp_page'				=> 'wf_EUV_ImportDefaultImages help page',
						'EUVphp_design_page'		=> 'wf_EUV_ImportDefaultImages design page',
					),
				));
				
	}
	
	

/**********************************
 * Class	: EUVLogging
 * ID		: wf_EUV_ImportDefaultImages
 * Release	: NA 
 * Date		: Created 06-11-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	: Check if the required images for the EUV extension are present and import them if not   
 * Info		:  
 * Function	:  ...Import default EUV images eg Active_No.png Active_Yes.png
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_ImportDefaultImages() {
		
		global $IP,$wgEUV_QBox_PHPBin;
		
		# ...Import default EUV images eg Active_No.png Active_Yes.png 
		# Create the path to the Mediawiki importImages.php script
		$ImportImagesScript = $IP.'/maintenance/importImages.php';
		
		# Create the path to the default Images
		$ImportImagesFrom 	= $IP.'/extensions/EUV/resources/';
		
		# Create the script command to upload the default Images not as user Admin , but as default user 'Maintenance script' 
		# info at https://www.mediawiki.org/wiki/Manual:ImportImages.php
		# This example creates an user="Admin" DB error .....  $ImageUploadCommand	= '--comment="default imported" --user="Admin" --search-recursively txt png jpg gif bmp PNG JPG GIF BMP';
		$ImageUploadCommand	= '--comment="default imported" --search-recursively --extensions=png,jpg,gif,bmp,PNG,JPG,GIF,BMP';
		$cmd = $wgEUV_QBox_PHPBin . ' ' . $ImportImagesScript . ' ' . $ImportImagesFrom . ' ' . $ImageUploadCommand;
		
		# Execute the Mediawiki importImages.php script
		$Shell_Result = shell_exec($cmd.' 2>&1 1');
			
		# make the output of the shell more readable
		$Dispay_Shell_Result = nl2br($Shell_Result);
		
		$Table_Result  = "\n";
		$Table_Result .= '{|class="wikitable mw-collapsible mw-collapsed"'."\n";
		$Table_Result .= '!Importing EUV images script logging'."\n";
		$Table_Result .= '|-'."\n";
		$Table_Result .= "| $Dispay_Shell_Result "."\n";
		$Table_Result .= '|}'."\n";
		
		# Check for an error during upload. The ^$ is checking an empty returned string when php is not operable
		# WATCH OUT.... ANY FILE NAME WITH THE BELOW TEXT WILL ALSO TRIGGER THE ERROR
		# The $Shell_Result should allways contain at the end ...  '''Found:''', 
		# Otherwise some files may not have been uploaded.  
		if ( preg_match('/Warning|Failed|Error|suitable|Could not open|^$/i', $Shell_Result ) ) {
				
				# Check for an error during upload. The ^$ is checking an empty returned string when php is not operable
				if ( preg_match('/^$/i', $Shell_Result) ) {
					# There was no responce from the script
					$Result_img = 'Active_No.png'; 
					$Script_output = " [[File:$Result_img]] " . wfMessage( "euv-upldefimg_nok" ) ."<br><br>&#09;<code>$ImportImagesFrom</code><br><br>";
					$Script_output .= wfMessage( "euv-upldefimg_noresponce" ).'<br>' ;
					$Script_output .= wfMessage( "euv-upldefimg_noresponce_solution1" ) ;
					}
					else {
						# There was an error message from the script
						$Result_img = 'Active_No.png'; 
						$Script_output = " [[File:$Result_img]] " . wfMessage( "euv-upldefimg_nok" ) ."<br><br>&#09;<code>$ImportImagesFrom</code><br><br>";
						$Script_output .= wfMessage( "euv-upldefimg_nok_solution1" ).'<br>' ;
						} 
			}
			else { 
				$Result_img = 'Active_Yes.png'; 
				$Script_output = " [[File:$Result_img]] " . wfMessage( "euv-upldefimg_ok" ) ."<br><br>&#09;<code>$ImportImagesFrom</code><br>";
			}
		
		$result = "\n".$Script_output . $Table_Result;
		 
	return $result; 
		
	}	
	
	
}
