<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */
 
 
 /*						TEST
 
 		// inject variables into an constant template
		$T_inject 	= array('p1'=>'10','p2'=>'20','p3'=>'30','p4'=>'30','p5'=>'30'); //$aa = array('10','20','30');
		$obj 		= new EUVTest($T_inject);
		
		print '1-'.$obj->EUV_T1."<br>"; 
		print '2-'.$obj->EUV_T2."<br>";
		//print '3-'.$obj->$_zzz."<br>";	
		
		print '<pre>';print_r($obj);print '</pre>';
 */


class EUVTest extends ArrayObject{

public  $EUV_T1;
public  $EUV_T2;

private $_variable;
private $_userName;

private $_zzz;

	public function __construct($T_array) {
		parent::__construct($T_array,ArrayObject::ARRAY_AS_PROPS);
		
		if( isset($T_array['p1']) && isset($T_array['p2']) && isset($T_array['p3']) ){
		
			$Template1 = <<<QBoxT1
=Testing the EUV template functionality=
Template1 .. $T_array[p1].xx.$T_array[p2]
aa
QBoxT1;

			$Template2 = <<<QBoxT2
=Testing the EUV template functionality=
Template2 .. $T_array[p2].xx.$T_array[p3]
bb
QBoxT2;

			if( isset($T_array['p5']) && is_numeric($T_array['p5']) ){ $this->_variable = $T_array['p5'];} else { $this->_variable = 1;}
			if( isset($T_array['p5']) && is_numeric($T_array['p5']) ){ print 'p5 is numeric'.'<br>';} else { print 'p5 is not numeric'.'<br>';;}
			
			$this->_userName = $this->_variable + 5;
			$this->_zzz = $this->_userName + 5;

	
			$this->EUV_T1 = $Template1 ;
			$this->EUV_T2 = $Template2 ;
		} else { 
			$this->EUV_T1 = 'missing' ;
			$this->EUV_T2 = 'missing' ;
			} 
	}	
	
	
	
}
