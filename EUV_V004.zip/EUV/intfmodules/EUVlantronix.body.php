<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVlantronix {
	
	# self::EUV_UDS1100_CharReadTimeout contains the wf_EUV_ReadUDS1100Char time out value
	const EUV_UDS1100_CharReadTimeout 	= 1;
	# self::EUV_UDS1100_LnReadTimeout contains the wf_EUV_ReadUDS1100Ln time out value
	const EUV_UDS1100_LnReadTimeout 	= 2;
	
	function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVlantronix'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVlantronix',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info	
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVlantronix'] = array(
					'EUVfilename'           			=> 'EUVlantronix.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_microtime_float'		=> array(
							'EUVhelp_page'				=> 'wf_EUV_microtime_float help page',
							'EUVphp_design_page'		=> 'wf_EUV_microtime_float design page',
						),
						'wf_EUV_CreateSocketTo_UDS1100'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_CreateSocketTo_UDS1100 help page',
							'EUVphp_design_page'		=> 'wf_EUV_CreateSocketTo_UDS1100 design page',
						),
						'wf_EUV_WriteTo_UDS1100'		=> array(
							'EUVhelp_page'				=> 'wf_EUV_WriteTo_UDS1100 help page',
							'EUVphp_design_page'		=> 'wf_EUV_WriteTo_UDS1100 design page',
						),
						'wf_EUV_ReadUDS1100Char'		=> array(
							'EUVhelp_page'				=> 'wf_EUV_ReadUDS1100Char help page',
							'EUVphp_design_page'		=> 'wf_EUV_ReadUDS1100Char design page',
						),
						'wf_EUV_ReadUDS1100Ln'			=> array(
							'EUVhelp_page'				=> 'wf_EUV_ReadUDS1100Ln help page',
							'EUVphp_design_page'		=> 'wf_EUV_ReadUDS1100Ln design page',
						),
						'wf_EUV_Test_UDS1100'			=> array(
							'EUVhelp_page'				=> 'wf_EUV_Test_UDS1100 help page',
							'EUVphp_design_page'		=> 'wf_EUV_Test_UDS1100 design page',
						),						
					));
						
				
	}	
			
	const	EUV_folder 								= '/EUV';
	const	EUV_tmp_folder  						= '/tmp';
	const	EUV_UDS1100_speedtest_received_file 	= '/uds1100_speedtest_received.txt';	
	
/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_microtime_float
 * Release	: NA 
 * Date		: Created 11-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	:  
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:   $fnc_start = self::wf_EUV_microtime_float();  
 * Implementation :   
 *  
 */
 	public static function wf_EUV_microtime_float(){
			list($usec, $sec) = explode(" ", microtime());
		return ((float)$usec + (float)$sec);
	}
	
/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_CreateSocketTo_UDS1100
 * Release	: NA 
 * Date		: Created 10-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Connect to an lantronix UDS1100 device   
 * Info		:  
 * Function	: create an socket to an lantronix UDS1100 device
 * Input	:  
 *			  
 * Output	: Success ==> Socket ID  
 *	     	  Failure ==> Empty 
 * Error	:
 * Example	:   $Socket_ID = wf_EUV_CreateSocketTo_UDS1100( wgEUV_QBox_LantronixUDS1100_1,'3001' );   
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_CreateSocketTo_UDS1100( $IPAddress,$LTPort ) { 
	
		# retrieve the error reporting  level
		$B_err_Report = error_reporting();
		# suppress error reporting
		error_reporting(0);
		# Initialise the result output
		$LanSocketID ='';
		
		$fp = fsockopen($IPAddress, $LTPort, $errno, $errstr, 1);
		  if (!$fp) { 
				EUVLogging::wf_EUV_DiagnosticsLogging('',"Failed to establish an telnet connection with the lantronix device at IP:$IPAddress Port:$LTPort fp:$fp with the error : $errno >> $errstr");
				$LanSocketID = ''; }
					else {
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Established an telnet connection with the lantronix device at IP:$IPAddress Port:$LTPort fp:$fp with the error :$errno >> $errstr");
						$LanSocketID = $fp; }
						
		# restore the error reporting level				
		error_reporting($B_err_Report);
						
	return array("LanSocketID"=>$LanSocketID,"errno"=>$errno,"errstr"=>$errstr);
		
	}

/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_WriteTo_UDS1100
 * Release	: NA 
 * Date		: Created 10-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Send data to an lantronix UDS1100 device   
 * Info		:  
 * Function	: Send data to an lantronix UDS1100 device
 * Input	:  		$socket			The required socket
 *			   		$sendString		The data to be send
 *					$decode			True  .. send by Binary decoding
 *									False .. send plain ascii
 *
 * Output	: Array
 *					NrofcharSend ==> Actual Nr of characters Send 
 *	     	  		write_stat	 ==> Error messages if any
 * Error	:
 * Example	:   $sendString 		= 'Hy there, i am testing the first Lantronix UDS1100';
 *				$wt_uds1100_result 	= self::wf_EUV_WriteTo_UDS1100( $socket1,$sendString,FALSE );
 * Implementation :   
 *  
 */
	
	public static function  wf_EUV_WriteTo_UDS1100( $socket,$sendString,$decode ) { 
	

			$fnc_start = self::wf_EUV_microtime_float();
			//$fnc_start = microtime();
			
			# remove from the string the non ascii characters
			# Returns FALSE if input contains character from outside the base64 alphabet.
			# base64_decode means binary
			$Write_error = false; 
			if ($decode) { $sendString = base64_decode($sendString); }
				else { $sendString = $sendString; }
			
			if( $sendString ){
					$Required_nrofchar_toSend 	= strlen( $sendString ) + 1 ;
					
					# The actual writing 
					$Actual_NrofcharSend 		= fwrite( $socket, $sendString."\n");
					
					# Check if we have send all
					if( $Required_nrofchar_toSend == $Actual_NrofcharSend ) 
						{ $fwrite_stat_msg = 'ok, we have send all characters'; } 
							else  { $Write_error = true; $fwrite_stat_msg = 'ERROR, we failed to send all characters';}
					}
				else { 	# There were illegal characters inside the $sendString
						$Actual_NrofcharSend = 0 ;
						$Write_error = true;						
						$fwrite_stat_msg = 'ERROR, we found none content inside the $sendString or in mode base64_decode illegal characters inside the $sendString';}

			#function execution time (ms)
			$fnc_end 	= self::wf_EUV_microtime_float();
			$duration 	= ($fnc_end-$fnc_start)*1000; 
			EUVLogging::wf_EUV_DiagnosticsLogging('',"wf_EUV_WriteTo_UDS1100 sendString:<span style='color:green'>$sendString</span> NrofcharSend:$Actual_NrofcharSend fwrite_stat:$fwrite_stat_msg duration:$duration");
	
	# Return the function results 	
	return array(	"NrofcharSend"=>$Actual_NrofcharSend,
					"write_stat_msg"=>$fwrite_stat_msg,
					"write_Error"=>$Write_error,
					"execute_time"=>$duration);
		
	}	
	
/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_ReadUDS1100Char()
 * Release	: NA 
 * Date		: Created 10-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Read an single character from the UDS1100   
 * Info		:  
 * Function	: Read an single character from the UDS1100  
 * Input	:  
 *			  
 * Output	: array==> 	"chr"=>	 An single character 
 * 						"timed_out"=>	 True: Time-out occured 
 * 						"blocked"=>		 True: Stream is in blocking IO mode
 * 						"eof"=>		 	 True: Stream has reached end-of-file
 * 						"stream_type"=>  The label describing the underlying implementation of the stream
 * 						"mode"=> 		 The type of access required for this stream
 * 						"unread_bytes"=> xx   :The number of bytes currently contained in the PHP's own internal buffer.
 * 						"seekable"=> 	 True:the current stream can be seeked
 * 						
 *	     	  Failure ==>  
 * Error	:
 * Example	:   $a = wf_EUV_ReadUDS1100Char( $socket1 )   
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_ReadUDS1100Char( $socket ) { 
	
			# Retrieve an single character from the device
			# self::EUV_UDS1100_CharReadTimeout contains the wf_EUV_ReadUDS1100Char time out value
			stream_set_timeout($socket, self::EUV_UDS1100_CharReadTimeout);
				$rdchr 	= fgetc($socket);
				$info 	= stream_get_meta_data($socket);
					
		return array(	"chr"=>$rdchr,
						"timed_out"=>$info['timed_out'],
						"blocked"=>$info['blocked'],
						"eof"=>$info['eof'],
						"stream_type"=>$info['stream_type'],
						"mode"=>$info['mode'],
						"unread_bytes"=>$info['unread_bytes'],
						"seekable"=>$info['seekable']
					);
		
	}	
	
/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_ReadUDS1100Char()
 * Release	: NA 
 * Date		: Created 10-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Read an single character from the UDS1100   
 * Info		:  
 * Function	: Read an single character from the UDS1100  
 * Input	:  
 *			  
 * Output	: array==> 	"chr"=>	 An single character 
 * 						"timed_out"=>	 True: Time-out occured 
 * 						"blocked"=>		 True: Stream is in blocking IO mode
 * 						"eof"=>		 	 True: Stream has reached end-of-file
 * 						"stream_type"=>  The label describing the underlying implementation of the stream
 * 						"mode"=> 		 The type of access required for this stream
 * 						"unread_bytes"=> xx   :The number of bytes currently contained in the PHP's own internal buffer.
 * 						"seekable"=> 	 True:the current stream can be seeked
 * 						
 *	     	  Failure ==>  
 * Error	:
 * Example	:   $a = wf_EUV_ReadUDS1100Char( $socket1 )   
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_ReadUDS1100Ln( $socket ) { 
			
			# Retrieve an Line (equal to readln) from the device
			# self::EUV_UDS1100_LnReadTimeout contains the wf_EUV_ReadUDS1100Ln time out value
			stream_set_timeout($socket, self::EUV_UDS1100_LnReadTimeout);
				$rdchr 	= fgets($socket);
				$info 	= stream_get_meta_data($socket);
					
		return array(	"chrline"=>$rdchr,
						"timed_out"=>$info['timed_out'],
						"blocked"=>$info['blocked'],
						"eof"=>$info['eof'],
						"stream_type"=>$info['stream_type'],
						"mode"=>$info['mode'],
						"unread_bytes"=>$info['unread_bytes'],
						"seekable"=>$info['seekable']
						);
		
	}	
	
/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_Test_UDS1100
 * Release	: NA 
 * Date		: Created 10-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Connect to lantronix UDS1100 devices and check the interface   
 * Info		:  
 * Function	: create and test an socket to the avaiable lantronix UDS1100 devices
 * Input	:  
 *			  
 * Output	: Success ==> Message  
 *	     	  Failure ==> Error messages
 * Error	:
 * Example	:   $Socket_ID = wf_EUV_CreateSocketTo_UDS1100( '192.168.1.81','3001' );   
 * Implementation :   
 *  
 */	
 	public static function wf_EUV_Test_UDS1100() { 
	
		global $wgEUV_QBox_LantronixUDS1100_1,$wgEUV_QBox_LantronixUDS1100_2;
	
			error_reporting(E_ALL);
		
			$LTPort = 3001;
			
			
			# Create an wiki table header to inject the actual used classes and functions 
			$result = " '''ASSURE THAT PIN2 AND PIN3 ARE CONNECTED TOGETHER''' \r\n";
			$result .= " \r\n";
			$result .= "{|class='wikitable' style='font-size: 90%;' \r\n";
			$result .= "|+ execute wf_EUV_Test_UDS1100 \r\n";			
			$result .= "|- \r\n";
			$result .= "! Func !! Result  \r\n";
			$result .= "|- \r\n";
		
			# establish an Socket to the devices
			$sf1 = self::wf_EUV_CreateSocketTo_UDS1100( $wgEUV_QBox_LantronixUDS1100_1,$LTPort );
				$socket1 	= $sf1['LanSocketID'];
				$err1 		= $sf1['errno'];
				$errmsg1 	= $sf1['errstr'];
			$sf2 = self::wf_EUV_CreateSocketTo_UDS1100( $wgEUV_QBox_LantronixUDS1100_2,$LTPort );
				$socket2 	= $sf2['LanSocketID'];
				$err2 		= $sf2['errno'];
				$errmsg2 	= $sf2['errstr'];
				
			# Add the result to the Test result table
			$result .= "| wf_EUV_CreateSocketTo_UDS1100 IP:$wgEUV_QBox_LantronixUDS1100_1  \r\n";
			$result .= "|socket: $socket1 error:<span style='color:red'>$err1</span> error msg:<span style='color:red'>$errmsg1</span> \r\n |- \r\n ";
			$result .= "| wf_EUV_CreateSocketTo_UDS1100 IP:$wgEUV_QBox_LantronixUDS1100_2  \r\n";
			$result .= "|socket: $socket2 error:<span style='color:red'>$err2</span> error msg:<span style='color:red'>$errmsg2</span> \r\n |- \r\n ";
			
			# The actual writing to the lantronix device
			if($socket1){
					$sendString 		= 'Hy there friend.... i am now testing the first Lantronix UDS1100';
					$wt_uds1100_result 	= self::wf_EUV_WriteTo_UDS1100( $socket1,$sendString,FALSE );
					$result .= "| fwrite socket1 IP:$wgEUV_QBox_LantronixUDS1100_1  \r\n";
					$result .= "| Send: $wt_uds1100_result[NrofcharSend] Characters , $wt_uds1100_result[write_stat_msg]  \r\n |- \r\n ";
					
					if( !$wt_uds1100_result['write_Error'] ){
					
							# Retrieve an single character from the device
							$rdchr 	= self::wf_EUV_ReadUDS1100Char( $socket1 );
							$result .= "| fgetc socket1 IP:$wgEUV_QBox_LantronixUDS1100_1 \r\n";
							$result .= " We should see the character '''<code>H</code>''' \r\n";
							$result .= "| wf_EUV_ReadUDS1100Char Receive the first single Char:<b>''' $rdchr[chr] '''</b> \n <span style='color:green'><nowiki> ";
							$result .= str_replace("true","</nowiki><b><span style='color:red'>true</span></b><nowiki> ",str_replace(",",",\n",json_encode($rdchr)));
							$result .= "</nowiki></span> \r\n |- \r\n ";
				
							# Retrieve another single character from the device
							$rdchr 	= self::wf_EUV_ReadUDS1100Char( $socket1 );
							$result .= "| fgetc socket1 IP:$wgEUV_QBox_LantronixUDS1100_1 \r\n";
							$result .= " We should see the character '''<code>y</code>''' \r\n";
							$result .= "| wf_EUV_ReadUDS1100Char Receive another single Char:<b>''' $rdchr[chr] '''</b> \n <span style='color:green'><nowiki> ";
							$result .= str_replace("true","</nowiki><b><span style='color:red'>true</span></b><nowiki> ",str_replace(",",",\n",json_encode($rdchr)));
							$result .="</nowiki></span> \r\n |- \r\n ";				
			
							# Read an single line from the device			
							$rdchr 	= self::wf_EUV_ReadUDS1100Ln( $socket1 );
							$result .= "| fgets socket1 IP:$wgEUV_QBox_LantronixUDS1100_1 \r\n";
							$result .= " We should see an complete Line \r\n";
							$result .= "| wf_EUV_ReadUDS1100Ln Receive an first Line:<b>''' ".rtrim($rdchr['chrline'])." '''</b> \n <span style='color:green'><nowiki> ";
							$result .= str_replace("true","</nowiki><b><span style='color:red'>true</span></b><nowiki> ",str_replace(",",",\n",json_encode($rdchr)));
							$result .="</nowiki></span> \r\n |- \r\n ";
				
							# Read another single line from the device
							$rdchr 	= self::wf_EUV_ReadUDS1100Ln( $socket1 );
							$result .= "| fgets socket1 IP:$wgEUV_QBox_LantronixUDS1100_1 \r\n";
							$result .= " We should see an <span style='color:green'>timed_out:</span><span style='color:red'>true</span> \r\n";
							$result .= "| wf_EUV_ReadUDS1100Ln Receive now another Line:<b>''' ".rtrim($rdchr['chrline'])." '''</b> \n <span style='color:green'><nowiki> ";
							$result .= str_replace("true","</nowiki><b><span style='color:red'>true</span></b><nowiki> ",str_replace(",",",\n",json_encode($rdchr)));
							$result .="</nowiki></span> \r\n |- \r\n ";	

							# UDS1100 file read / write test
							self::wf_EUV_CheckLantronixFilePaths();
							$result .= self::wf_EUV_Test_UDS1100FileReadWrite($socket1);
									
					} 
					else { $result .= "| <span style='color:red'>We have an UDS1100 write error. Test aborted</span> \r\n  || |- \r\n ";}
		
			}
			else { $result .= "| fwrite to socket1 disabled. ||  <span style='color:red'>No socket avaiable</span>  \r\n |- \r\n ";}
			# End of the test		
			# Close the sockets if exist 
			if($socket1){ fclose($socket1); }					
					
					
			# The actual test of the other lantronix device
			if($socket2){
					$sendString 		= 'Hy there, i am now testing the first Lantronix UDS1100';
					$wt_uds1100_result 	= self::wf_EUV_WriteTo_UDS1100( $socket2,$sendString,FALSE );
					$result .= "| fwrite socket2 IP:$wgEUV_QBox_LantronixUDS1100_2  \r\n";
					$result .= "| Send: $wt_uds1100_result[NrofcharSend] Characters , $wt_uds1100_result[write_stat]  \r\n |- \r\n ";
			}
			else { $result .= "| fwrite to socket2 disabled. || <span style='color:red'>No socket avaiable</span>  \r\n |- \r\n ";}
			# End of the test		
			# Close the sockets if exist 	
			if($socket2){ fclose($socket2); }
			
			# close the Test result table 
			$result .= "|} \r\n";


	return $result;
	
	}

/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_ChecLantronixFilePaths
 * Release	: NA 
 * Date		: Created 12-11-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	: Check if the required folders for the EUV extension are present and create them if not   
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_CheckLantronixFilePaths() { 
		global $wgUser,$wgUploadDirectory;
		
			# add info to the Diagnostics Logging file		
			EUVLogging::wf_EUV_DiagnosticsLogging('F',"Start wf_EUV_ChecLantronixFilePaths");
			# retrieve the constants of the folder allocations 
			$EUV_path 					= $wgUploadDirectory.self::EUV_folder;
			$EUV_Lantronix_tmp_path 	= $EUV_path.self::EUV_tmp_folder;
			$Log_file					= $EUV_Lantronix_tmp_path.self::EUV_UDS1100_speedtest_received_file;
				
			# Create the EUV and EUV Diagnostics logging folder if they not exist
			$EUV_path 					= $wgUploadDirectory.self::EUV_folder;
			$EUV_Lantronix_tmp_path 	= $EUV_path.self::EUV_tmp_folder;
			
			# add info to the Diagnostics Logging file
			EUVLogging::wf_EUV_DiagnosticsLogging('',"checking if folder $EUV_path exist");
			
			# Check for the existance of the appropiate folder 
			if( !is_dir( $EUV_path ) ){ 
			
				# The folder is not present, so we need to create one
				mkdir($EUV_path, 0777);
				# Set the appropiate rights of the folder
				chmod($EUV_path, 0774);
				# add info to the Diagnostics Logging file
				EUVLogging::wf_EUV_DiagnosticsLogging('',"$EUV_path does not exist, created new one");
				# whenever we can't create the folder, create an system error
				if( !is_dir( $EUV_path ) ){ trigger_error("folder $EUV_path creation Error: ", E_USER_ERROR);}
				
			}
				
			# add info to the Diagnostics Logging file
			EUVLogging::wf_EUV_DiagnosticsLogging('',"checking if folder $EUV_Lantronix_tmp_path exist");
			# Check for the existance of the appropiate folder 
			if( !is_dir( $EUV_Lantronix_tmp_path ) ){	
				# The folder is not present, so we need to create one			
				mkdir($EUV_Lantronix_tmp_path, 0777);
				# Set the appropiate rights of the folder
				chmod($EUV_Lantronix_tmp_path, 0774);
				# add info to the Diagnostics Logging file
				EUVLogging::wf_EUV_DiagnosticsLogging('',"$EUV_Lantronix_tmp_path, created new one");
				# whenever we can't create the folder, create an system error
				if( !is_dir( $EUV_Lantronix_tmp_path ) ){ trigger_error("folder $EUV_Lantronix_tmp_path creation Error: ", E_USER_ERROR);}				
				}
			
			# add info to the Diagnostics Logging file			
			EUVLogging::wf_EUV_DiagnosticsLogging('F',"End wf_EUV_ChecLantronixFilePaths");
			
		return;
		
	}	
/**********************************
 * Class	: EUVlantronix
 * ID		: wf_EUV_Test_UDS1100FileReadWrite($socket)
 * Release	: NA 
 * Date		: Created 11-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Test the read / write performance of an UDS1100   
 * Info		:  
 * Function	: Send an file to and receive from an UDS1100
 * Input	:  
 *			  
 * Output	: Success ==> Message  
 *	     	  Failure ==> Error messages
 * Error	:
 * Example	:   $result = wf_EUV_Test_UDS1100FileReadWrite($Socket_ID);  
 * Implementation :   
 *  
 */	
	public static function wf_EUV_Test_UDS1100FileReadWrite($socket) {
		global $wgUploadDirectory;
		
			# UDS1100 read / write test
			$fnc_start = self::wf_EUV_microtime_float();
			$result = "| UDS1100 Read/Write test  ||\r\n";
			# assign an test file
			$sourcefile 		=__DIR__ . '/uds1100_speedtest_sendto.txt';
			$destinationfile 	= $wgUploadDirectory.self::EUV_folder.self::EUV_tmp_folder.self::EUV_UDS1100_speedtest_received_file;
			# Open the test file for reading
			$rhandle = fopen($sourcefile, "r");
			$whandle = fopen($destinationfile, "w");
			fclose($whandle);
			# If the file is valid and can be accessed 
			if ( $rhandle && $whandle ) {
					$avg_linespeed;
					$i=0;
					# perform during the entire readln of the file
					$ReadUDS1100Ln_timed_out = False;
					while ( ($line = fgets($rhandle)) !== false  && !$ReadUDS1100Ln_timed_out )  {
							# Write an compete line to the UDS1100
							$line = trim($line);							
							$wt_uds1100_result 	= self::wf_EUV_WriteTo_UDS1100( $socket,$line,FALSE );
							# Check if we were able to send the correct number of characters
							if ( (($wt_uds1100_result['NrofcharSend']-1) == strlen($line)) && !$wt_uds1100_result['write_Error'] ){ 
										# count the total amount of characters send 
										$i = $i + $wt_uds1100_result['NrofcharSend'];
										$avg_linespeed[] = $wt_uds1100_result['execute_time'] / $wt_uds1100_result['NrofcharSend'];}
									else { $result .= "<span style='color:red'>speed test write error</span> \r\n";}
							# Get the received data out of the UDS1100
							$UDS_Readline = self::wf_EUV_ReadUDS1100Ln( $socket );
							if( $UDS_Readline['timed_out'] ){ 
								file_put_contents($destinationfile, 'ERROR: UDS_Readline Time out detected'."\r\n", FILE_APPEND | LOCK_EX);
								$ReadUDS1100Ln_timed_out = True;}
									else {file_put_contents($destinationfile, $UDS_Readline['chrline']."\r\n", FILE_APPEND | LOCK_EX);}
					}
							
					$fnc_end 	= self::wf_EUV_microtime_float();	
					$duration 	= ($fnc_end-$fnc_start); 						
					# list the result of the test	
					$result .= " AVG char transmit speed during ".count($avg_linespeed)." lines with in total $i characters = " . ((array_sum($avg_linespeed)/$i)*1000)  . " [us]  \r\n ";	
					$result .= "Total send file to UDS1100 duration = " . array_sum($avg_linespeed) . " [ms]  \r\n ";
					if( $ReadUDS1100Ln_timed_out ){ $result .= "<span style='color:red'>ERROR: UDS_Readline Time out detected.</span> Test has been terminated \r\n ";}
					$result .= "Total send file to and receive file from UDS1100 duration: $duration [s]  \r\n \r\n ";			
					$result .= "'''<b>UDS1100 Read/Write test is finished with error Status: $ReadUDS1100Ln_timed_out <nowiki>[<nothing> means OK, 1 means Failed]</nowiki></b>''' \r\n |- \r\n";
					fclose($rhandle);
			} 
			else { 	# error opening the file
					$result .= " <span style='color:red'>Error opening </span> <code> $sourcefile \r \r or $destinationfile </code> \r\n |- \r\n"; }
								
		return $result;

	}
	
	
}
