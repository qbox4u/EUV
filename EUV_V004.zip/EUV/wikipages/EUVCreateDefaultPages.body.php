<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVCreateDefaultPages {
	
		function __construct(){
			
 		global $wgEUVFuncCredits;
		$wgEUVFuncCredits['EUVCreateDefaultPages'][] = array(
				'version'				=> '1.0.0',
				'path'           		=> __FILE__,
				'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
				'description' 			=> 'PHP Master: EUVCreateDefaultPages',
				'license-name' 			=> 'Licence',
				'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		global $wgEUVFuncinfo;	
		$wgEUVFuncinfo['EUVCreateDefaultPages'] = array(
				'EUVfilename'           		=> 'EUVCreateDefaultPages.body.php',
				'EUVfunctions'					=> array( 
					'wf_EUV_CreateDefaultPages'	=> array(
					'EUVhelp_page'				=> 'wf_EUV_CreateDefaultPages help page',
					'EUVphp_design_page'		=> 'wf_EUV_CreateDefaultPages design page',
					),						
				));
				
		}
	
/**********************************
 * ID		: EUVDefaultPages
 * Release	: NA 
 * Date		: Created 28-10-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	: Create automatically wiki pages
 * Info		: [[Help:Update default Wiki pages]] 
 *            [[Class EUVDefaultPagesUpdate Create default Wiki pages php design info]] 
 * Function	: NON existing pages will be automatically created 
 *			  Existing pages will be updated only if constant EUV_AllowUpdatePage = TRUE;
 * Input	: $Required_EUV_Default_Pages 
 *			  		array('page name 1'	=>$page_content1, 'page name 2'	=>$page_content2)
 * Output	: Success ==>   
 *	     	  Failure ==> 
 * Uses		: EUVLogging::wf_EUV_DiagnosticsLogging
 * Error	:
 * Example	: 	$DefaultPages = new EUVCreateDefaultPages();
 * 				$result = $DefaultPages->wf_EUV_CreateDefaultPages();
 * 				$output->addWikiText($result); 
 * 	 
 * Implementation :   
 *  
 */
 
	# Enable or Disable the automatic creation of QBox4u EUV Wiki pages
	#    Enable creation  : const EUV_AllowUpdatePage = TRUE;
	#	 Disable creation : const EUV_AllowUpdatePage = FALSE;
	const EUV_AllowUpdatePage = FALSE;

	# Local page content 
	const EUV_DemoPage = <<<EUVDP
	
{{EUV}}
=Testing the EUV functionality=
EUVDP;
	# Local page content
	const EUV_Template = <<<QBoxFSP

=Testing the EUV template functionality=
QBoxFSP;
	# Local page content
	const EUV_Help = <<<QBoxFSP

=Help page=
default page

You must update and save it as another page
QBoxFSP;


	public static function wf_EUV_CreateDefaultPages() { 
	
		global $wgUser,$parser;

			$PID = getmypid();
					
			/******************
 			* Protect against register_globals vulnerabilities.
			* This line must be present before any global variable is referenced.
 			* Alert the user that this is not a valid access point to MediaWiki if they try to access 
 			* the application file directly 
			*/
			if( !defined( 'MEDIAWIKI' ) )  {
				echo( "<h3><p style='color:red'>****************  WARNING  WARNING  WARNING *****************<br>\n" );
				echo( "****************      EXECUTION TERMINATED   *********************</p></h3>\n" );
				echo( "This is an class extension to the QBox EUV MediaWiki package and cannot be used to run standalone.<br>\n" );
				echo( "This is an restricted application, only to be used inside the QBox4u QNAP TS-459 proII server!!!<br>\n" );
				echo( "This application has been terminated at ".date("F j, Y, g:i a")."  by illegal and/or unauthorized access<br> \n" );
				echo( "<h2>Contact the  <a href='https://www.linkedin.com/in/jan-boer-a24640113'> author</a> or email qbox4u@gmail.com</h2><br>\n" );
				die( -1 );
			}	
			
			# Assign an dummy page injection 
			$Page_inject 	= array('p1'=>'10','p2'=>'20','p3'=>'30','p4'=>'30','p5'=>'30'); 
	
			# The following QBox4u EUV pages are defined in an EUV Class
			#
			# Retrieve master page template for : EUV Page 01 
			$obj			= new EUVPage01($Page_inject);
			$page_p1 		= $obj->EUV_P1;
			# Retrieve master page template for : Template:TQM
			$obj 			= new EUVPageTemplateTQM($Page_inject);
			$page_p2 		= $obj->TemplateTQM;
			# Retrieve master page template for : Template:EUV
			$obj 			= new EUVPageTemplateEUV($Page_inject);
			$page_p3 		= $obj->TemplateEUV;
			# Retrieve master page template for : Create EUV extension
			$obj 			= new EUVPageCreateEUVextension($Page_inject);
			$page_p4 		= $obj->CreateEUVextension;
			# Retrieve master page template for : Category:QBox_EUV
			$obj 			= new EUVPageCategoryEUV($Page_inject);
			$page_p5 		= $obj->CategoryEUV;
			# Retrieve master page template for : Test EUV Tags
			$obj 			= new EUVPageTestEUVTags($Page_inject);
			$page_p6 		= $obj->TestEUVTags;
			# Retrieve master page template for : Test EUV Tags
			$obj 			= new EUVPageHelpUpdatedefaultWikipages($Page_inject);	
			$page_p7 		= $obj->HelpUpdatedefaultWikipages;
			# Retrieve master page template for : Template:TQM
			$obj 			= new EUVPageTemplateEFU($Page_inject);
			$page_p8 		= $obj->TemplateEFU;
			# Retrieve master page template for : Category:QBox_EUV
			$obj 			= new EUVPageCategoryEFU($Page_inject);
			$page_p9 		= $obj->CategoryEFU;


			# Identify the present user and his permissions
			$User 	= $wgUser;
			$access = $wgUser->isAllowed( 'read' );
		
			EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_CreateDefaultPages ");
		
			# Define the list of default pages and its content
			# The pages with self:: need to be added by yourseves
			$Required_EUV_Default_Pages = array(
				'EUV Page 01'						=>$page_p1,
				'EUV extension demo page'			=>self::EUV_DemoPage,	
				'EUV Admin Work in process'			=>self::EUV_DemoPage,					
				'Template:TQM'						=>$page_p2,
				'Template:EUV'						=>$page_p3,
				':Category:QBox_EUV'				=>$page_p5,
				'Template:EFU'						=>$page_p8,
				':Category:QBox_EFU'				=>$page_p9,
				'Create EUV extension'				=>$page_p4,
				'Test EUV Tags'						=>$page_p6,
				'Help:Update default Wiki pages'	=>$page_p7
				);

			# Create the wiki table header to insert the result of the function
			$result = "";
			
			$result .= "{| class='wikitable sortable' cellpadding='0' cellspacing='0' style='font-size: 90%; text-align:center;' ". "\r\n";
			//$result .= "|+ Check for Required Updates of the default QBox EUV Wiki pagess \r\n";
			$result .= "!Page [[File:System-help.png|25px|link=Help:Update default Wiki pages#Page]] \r\n";
			$result .= "!Allow Updates [[File:System-help.png|25px|link=Help:Update default Wiki pages#Allow Updates]] \r\n";
			$result .= "!Page version [[File:System-help.png|25px|link=Help:Update default Wiki pages#Page version]]<br>Requires update? \r\n";
			$result .= "!Updated [[File:System-help.png|25px|link=Help:Update default Wiki pages#Updated]]<br>Is page renewed? \r\n";
			$result .= "|-\r\n";
			
			if ( self::EUV_AllowUpdatePage ) { $EUV_AllowUpdatePage_icon = '[[File:Dialog-yes.png|25px|link=Help:Update_default_Wiki_pages#Allow_Updates]]';} 
				else { $EUV_AllowUpdatePage_icon = '[[File:Dialog-no.png|25px|link=Help:Update_default_Wiki_pages#Allow_Updates]]'; }
				
			# Check the availability of all default EUV pages, and create the missing ones ( if the user is allowed to do so) 
			foreach ($Required_EUV_Default_Pages  as $Page_Name =>$Page_Content) {
				$newPageTitle = $Page_Name;
				$titleObject = Title::newFromText( $Page_Name );
				
				# Check if the page exist 
				if ( $titleObject->exists() && !self::EUV_AllowUpdatePage ) { 
				
						# The page is existing and we do not allow updates of the pages. You can skip.
						$Update_page = FALSE;
						$newarticle = new Article(Title::newFromText($newPageTitle), 0);							 
						$orgtext = $newarticle->getContent();#getText()   getContent()

						# Check if the actual and the master page contents are the same
						# Make sure you remove the rubbish at each end 
						if ( strcmp(rtrim($orgtext),rtrim($Page_Content)) !== 0 ) { 
						
								# The actual and the master page contents are NOT the same
								# Add this result to the wiki table
								$result .= "|style='text-align:left;'|[[$Page_Name]]||$EUV_AllowUpdatePage_icon|| [[File:Dialog-yes.png|25px|link=Help:Update_default_Wiki_pages#Page_version]]|| [[File:Dialog-no.png|25px|link=Help:Update_default_Wiki_pages#Updated]] \r\n|-\r\n";

								#In case you have problems to understand why an page update request is generated, use the following Class function
								#echo "$newPageTitle are not the same <br>";
								#$obj = new EUVDiff;
								#$difference = $obj->compare($orgtext,$Page_Content);
								#print'<pre>';print_r($difference);print '</pre> <br>';
								#echo '<br>**** org start *********<br>'.$orgtext.'<br>**** aa org end *********<br>';	
								#echo '<br>**** Page_Content start *********<br>'.$Page_Content.'<br>****Page_Content end *********<br>';
								#echo '*********************************************************************************************************************<br>';							

								}
							else { 
								# The actual and the master page content are identical
								# Add this result to the wiki table
								$result .= "|style='text-align:left;'|[[$Page_Name]]||$EUV_AllowUpdatePage_icon|| [[File:Dialog-no.png|25px|link=Help:Update_default_Wiki_pages#Page_version]] ||[[File:Dialog-no.png|25px|link=Help:Update_default_Wiki_pages#Updated]] \r\n|-\r\n";
								} 
						
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Page $newPageTitle exist");} 
				
				  else {
						# There is no page with the name $newPageTitle or we all an page update . 
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Enable an update of $newPageTitle if EUV_AllowUpdatePage is 1. Status :<span style='color:red'>" . self::EUV_AllowUpdatePage .'</span>');
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Page $newPageTitle does not exist");
						
						# Create an new page with the title $newPageTitle if the user is allowed to create pages
						if ( $wgUser->isAllowed( 'createpage' ) ) {
							 $Update_page = TRUE;
							 EUVLogging::wf_EUV_DiagnosticsLogging('',"User is allowed to create Page $newPageTitle. Starting to create the page");
							 
							 # Create an new page
							 $newarticle = new Article(Title::newFromText($newPageTitle), 0);	
							 $newarticle->doEdit( $Page_Content, EDIT_UPDATE );
							 
							 # Add this result to the wiki table
							 $result .= "|style='text-align:left;'|[[$Page_Name]]||$EUV_AllowUpdatePage_icon|| [[File:Dialog-yes.png|25px|link=Help:Update_default_Wiki_pages#Page_version]]||[[File:Dialog-yes.png|25px|link=Help:Update_default_Wiki_pages#Updated]] \r\n|-\r\n";
							 EUVLogging::wf_EUV_DiagnosticsLogging('',"Page <b><span style='color:green'>$newPageTitle</span></b> created ");	
							}	 
							else { 
								# The user is not allowed to Create an new page with the title $newPageTitle  
								$Update_page = FALSE;
								# Add this result to the wiki table
								$result .= "|style='text-align:left;'|[[$Page_Name]]||$EUV_AllowUpdatePage_icon||[[File:Dialog-yes.png|25px|link=Help:Update_default_Wiki_pages#Page_version]]||[[File:Dialog-no.png|25px|link=Help:Update_default_Wiki_pages#Updated]] \r\n|-\r\n";
								EUVLogging::wf_EUV_DiagnosticsLogging('',"User is <span style='color:red'>not allowed</span> to create Page $newPageTitle ");	}
					}
			}
			# Create an end for the wiki table
			$result .= "|-\r\n";
			
			$html_result = " \r\n";
			$html_result .= '{|class="wikitable sortable mw-collapsible mw-collapsed" cellpadding="0" cellspacing="0" style="white-space: nowrap;font-size:12px;" '."\r\n";
			$html_result .= "|style='background:#ffdead;' | ''' CLICK ON EXPAND TO VIEW THE STATUS, OR ON COLLAPSE TO HIDE THE TEST''' "."\r\n";
			$html_result .= "|- \r\n| \r\n";
			
			$html_result .= $result;
			
			$html_result .= '|}'."\r\n";
			
			
			EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_CreateDefaultPages");
		
		# Return the result of the function
		return $html_result;			
	}
			
		
}	
	

