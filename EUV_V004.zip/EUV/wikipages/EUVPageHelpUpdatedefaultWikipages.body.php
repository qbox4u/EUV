<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

/**********************************
 * Class	: EUVPageHelpUpdatedefaultWikipages
 * Release	: V1.0 
 * Date		: Created 4-11-2016 by JBoe
 * Notes	: Impementation of QBox EUV WIKI Pages
 *
 * Purpose	: Create an QBox Wiki help page  
 * Info		:  
 * Function	: Inject parameters into an Wiki page template 
 * Input	: $T_array
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	: 	$Page_inject 	= array('p1'=>'10','p2'=>'20','p3'=>'30','p4'=>'30','p5'=>'30'); 
				$obj 			= new EUVPageHelpUpdatedefaultWikipages($Page_inject);
				$page 			= $obj->EUVPageHelpUpdatedefaultWikipages;
				print $page .'<br>';
				print '<pre>';print_r($obj);print '</pre>'
 *			  
 * Implementation :   
 *  
 */
 
class EUVPageHelpUpdatedefaultWikipages extends ArrayObject{

public  $HelpUpdatedefaultWikipages;

	public function __construct($T_array) {
		parent::__construct($T_array,ArrayObject::ARRAY_AS_PROPS);
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVPageHelpUpdatedefaultWikipages'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVPageHelpUpdatedefaultWikipages',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info		
		global 	$wgEUVFuncinfo;	
				$wgEUVFuncinfo['EUVPageHelpUpdatedefaultWikipages'] = array(
					'EUVfilename'           						=> 'EUVPageHelpUpdatedefaultWikipages.body.php',
					'EUVfunctions'									=> array( 
						'EUV_PageTemplate_UpdatedefaultWikipages'	=> array(
							'EUVhelp_page'							=> 'EUV_PageTemplate_UpdatedefaultWikipages help page',
							'EUVphp_design_page'					=> 'EUV_PageTemplate_UpdatedefaultWikipages design page',
						),						
					));		
		
# This is the RAW QBox Wiki page definition
# All variables need to be created and/or updated and inserted into the page before returning the page

		$EUV_PageTemplate_UpdatedefaultWikipages = <<<QBoxPT1
=Introduction=
Wiki Pages inside the extension <code>EUV</code>EUV can be installed and/or updated automatically

This feature is performed by the class <code>EUVCreateDefaultPages</code>
 
=Installation=

Add inside <code>extension.json</code> the following line
 <code>"EUVCreateDefaultPages":  "wikipages/EUVCreateDefaultPages.body.php",</code>

Add to inject the status list at the desired location of your appication the following 3 lines
 
 <code>&#36;DefaultPages = new EUVCreateDefaultPages();</code>
 
 <code>&#36;result = &#38;DefaultPages->wf_EUV_CreateDefaultPages();</code>
 
 <code>&#36;output->addWikiText(&#36;result);</code>

=Function=
Create the QBox pages
=Parameters=
{|class="wikitable"
|-
|const EUV_AllowUpdatePage = TRUE OR FALSE || Create pages if they don't exist
|-
|const EUV_AllowUpdatePage = FALSE || Dis_allow updating pages
|-
|const EUV_AllowUpdatePage = TRUE || allow updating pages
|}


The Class will create the QBox pages as assigned in the array <code>&#36;Required_EUV_Default_Pages</code>

 Array  ( ' PAGE NAME 1' => ' PAGE CONTENT 1', ' PAGE NAME 2' => ' PAGE CONTENT 2' etc, etc )

<pre>
# Define the list of default pages and its content
&#36;Required_EUV_Default_Pages = array(
	'EUV Page 01'				=>&#36;page_p1,		
	'Template:TQM'				=>&#36;page_p2,
	'Template:EUV'				=>&#36;page_p3,
	':Category:QBox_EUV'			=>&#36;page_p4,
	'Help:Update default Wiki pages'	=>&#36;page_p5,
	 etc 
	 etc
	'Template:EUV'				=>&#36;page_p99
	);
</pre> 
 NOTE: An Category page eg <code>Category:QBox_EUV</code> page should be preceded by an  <big>'''<code>:</code>'''</big>

= Output table =
The Output table contains the result of the function
 
[[File:Update_Admin_wikipages_01.png]]  
===Page===
 This column contains the name of the page and an direct link to the wiki page
===Allow Updates===
 This column contains the result of the status of <code>const EUV_AllowUpdatePage</code>

{|
|-
 |[[File:Dialog-yes.png|35px]]|| means: '''Updating of the page is allowed'''
|-
 |[[File:Dialog-no.png|35px]]|| means: '''Updating of the page is <span style="color:red">Not allowed</span>'''
|}

===Page version===
 This column contains the information if the content of the page is up to date
{|
|-
 |[[File:Dialog-yes.png|35px]]|| means: '''A new version of the Page is available and <span style="color:red">Page requires an update</span>''' 
|-
 |[[File:Dialog-no.png|35px]]|| means: '''Updating of the page is not required'''
|}

===Updated===
 This column contains the information if the content of the page has been updated or not
{|
|-
 |[[File:Dialog-yes.png|35px]]|| means: '''A new version of the Page has been injected''' 
|-
 |[[File:Dialog-no.png|35px]]|| means: '''Updating of the page is <span style="color:red">Rejected and not performed</span>'''
|}

=Examples=
 This example has set <code>const EUV_AllowUpdatePage</code> to <big>'''TRUE'''</big>
{|
|-
|[[File:Update_Admin_wikipages_02.png|400px]] 
|}

 This example has set <code>const EUV_AllowUpdatePage</code> to <big>'''FALSE'''</big>
 
 An page has an new version, but because <code>const EUV_AllowUpdatePage</code> = <big>'''FALSE'''</big> the page is not updated
{|
|-
|[[File:Update_Admin_wikipages_05.png|400px]]  
|}


QBoxPT1;
	
		$this->HelpUpdatedefaultWikipages = $EUV_PageTemplate_UpdatedefaultWikipages ;

	}	
	
}
