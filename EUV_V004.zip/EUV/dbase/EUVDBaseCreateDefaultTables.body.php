<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVDBaseCreateDefaultTables {

	function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVDBaseCreateDefaultTables'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVDBaseCreateDefaultTables',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
		# The EUV extension Class info	
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVDBaseCreateDefaultTables'] = array(
					'EUVfilename'           			=> 'EUVCreateDefaultTables.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_Create_Default_Tables'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_Create_Default_Tables help page',
							'EUVphp_design_page'		=> 'wf_EUV_Create_Default_Tables design page',
						),	
						'wf_EUV_Create_Default_Tables_query'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_Create_Default_Tables_query help page',
							'EUVphp_design_page'		=> 'wf_EUV_Create_Default_Tables_query design page',
						),
						'wf_EUV_Check_Available_DBTables'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_Check_Available_DBTables help page',
							'EUVphp_design_page'		=> 'wf_EUV_Check_Available_DBTables design page',
						),	
						'wf_EUV_Check_ValidDBUserconfig_json'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_Check_ValidDBUserconfig_json help page',
							'EUVphp_design_page'		=> 'wf_EUV_Check_ValidDBUserconfig_json design page',
						),
						'wf_EUV_DBReadUserconfig_jsonRecords'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_DBReadUserconfig_jsonRecords help page',
							'EUVphp_design_page'		=> 'wf_EUV_DBReadUserconfig_jsonRecords design page',
						),
						'wf_EUV_DBUpdate_jsonRecords'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_DBUpdate_jsonRecords help page',
							'EUVphp_design_page'		=> 'wf_EUV_DBUpdate_jsonRecords design page',
						),
						'wf_EUV_DBRetrieve_jsonRecords'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_DBRetrieve_jsonRecords help page',
							'EUVphp_design_page'		=> 'wf_EUV_DBRetrieve_jsonRecords design page',
						),
					));
				
	}	

/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_Create_Default_Tables 
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
	function wf_EUV_Create_Default_Tables(){

		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname,$wgEuvUserconfig_json;

		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_Create_Default_Tables");
		$func_error = false;
		
		$db_select_obj = mysqli_connect( $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname);
		if ( !$db_select_obj == null ){

			mysqli_set_charset($db_select_obj, "utf8");
			
			$DBQuerySet = self::wf_EUV_Create_Default_Tables_query(); # print'<pre>';print_r($DBQuerySet);print'</pre>';
			
			# Create for each json groep an new table
			foreach ( $DBQuerySet as $JSkey => $JSvalue ){
				foreach ( $JSvalue as $key => $value ){
					
					# The table name
					$wtnam = $JSkey;
					# The table items definition
					$wtdef = $value['table_definition'];
					# The table items value
					$wtval = $value['table_values'];

					# Drop the table if the table exist
					$DBWtable 	= $wtnam;
					$query		= "DROP TABLE IF EXISTS $DBWtable";						
					$qresult = mysqli_query($db_select_obj,$query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($mysqli), E_USER_ERROR);
					EUVLogging::wf_EUV_DiagnosticsLogging(''," Performed query.. result $qresult query: $query " );
					
					# Create new TABLE 
					$query		= $wtdef;						
					$qresult 	= mysqli_query($db_select_obj,$query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($mysqli), E_USER_ERROR);
					EUVLogging::wf_EUV_DiagnosticsLogging(''," Performed query.. result $qresult query: $query " );

					# Inject the data into the new table only if the table exist 
					if ($qresult == 1){
						# Inject the data into the new table 
						$query 		= $wtval;
						$qresult 	= mysqli_query($db_select_obj,$query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($mysqli), E_USER_ERROR);
						EUVLogging::wf_EUV_DiagnosticsLogging(''," Performed query.. result $qresult query: $query " );
						} 
						else { 	$func_error = true; 
								EUVLogging::wf_EUV_DiagnosticsLogging(''," error during creation of the table: $wtnam. Injection of Table Values is canceled " ); }
				}
			}	
			$dbclosing = mysqli_close($db_select_obj) or trigger_error("SQL closing - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			if(!$dbclosing) { $func_error = true;  } 

		} 
		else { # Failed to login into the database
				EUVLogging::wf_EUV_DiagnosticsLogging('','<span style="color:red">Error: Can\'t log into the MySQL server. err:'. mysql_error().' </span>' );
				$func_error = true; }
				
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_Create_Default_Tables");
		
	return 	$func_error;
	
	}

/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_Create_Default_Tables_query 
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
	function wf_EUV_Create_Default_Tables_query(){

		global $wgEUV_UserconfigurationFile,$wgDBprefix,$wgUser;

			EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_Create_Default_Tables_query");
			
			# Retrieve the default jason User configuration File into the associative array $euvjsuserconfig
			# The /../ means that we go "UP one folder 
			$fd 					= __DIR__ .'/../'.$wgEUV_UserconfigurationFile;
			$jsonString 			= file_get_contents($fd);
			$userconfigjsonchksum 	= md5( $jsonString );
			$euvjsuserconfig 		= json_decode($jsonString, true);
			EUVLogging::wf_EUV_DiagnosticsLogging('',"Retrieved $fd");
			
			# Create an date
			$today 				= date("Y\-m\-j");
			$usr 				= $wgUser->getName();
			$DBQuerySet;
			# 
			foreach ( $euvjsuserconfig as $JSkey => $JSvalue ){
				
				# The table name
				$tnam = $wgDBprefix.$JSkey;
				EUVLogging::wf_EUV_DiagnosticsLogging('',"Create the DB query and values array for table $tnam ");
				
				# The table items name definition
				$tdef = 'CREATE TABLE '.$wgDBprefix.$JSkey.' (id int(6) NOT NULL auto_increment, AUTHOR varchar(25) NOT NULL, MODDATE varchar(10) NOT NULL,';
				# The table items values
				$tval = 'INSERT INTO '.$wgDBprefix.$JSkey.' VALUES (\'\',\''.$usr.'\',\''.$today.'\'';
				
				foreach ( $JSvalue as $key => $value ){
					
					# Add the item name into the table definition
					$tdef .= $key . ' varchar(35)' . ' NOT NULL, ';
					# Add the item value into the table value
					if( $key === 'EUVPresentUserconfigjsonmd5'){
						    $tval .= ',\''.$userconfigjsonchksum.'\'';
						} 
						else {# inject the checksum md5 value of the Userconfigjson file
							  $tval .= ',\''.$value.'\'';}
				}
				
				# Finalize the table items definition
				$tdef .= ' PRIMARY KEY (id), UNIQUE id (id), KEY id_2(id) )';
				# Finalize the table values definition
				$tval .= ') ';
				$DBQuerySet[$tnam][]=array('table_definition'=>$tdef,'table_values'=>$tval);	
			}			
			
			EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_Create_Default_Tables_query");
			
	return 	$DBQuerySet;
	
	}
	
/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_Check_Available_DBTables
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
	function wf_EUV_Check_Available_DBTables(){

		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname,$wgEuvUserconfig_json;

		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_Check_Available_DBTables");
		
		$func_result = false;
		$db_select_obj = mysqli_connect( $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname);
		if ( !$db_select_obj == null ){
			$Available_DBTables;
			mysqli_set_charset($db_select_obj, "utf8");
			$query		= "SHOW TABLES IN $wgDBname";	
			$qresult 	= mysqli_query($db_select_obj,$query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			EUVLogging::wf_EUV_DiagnosticsLogging(''," Performed query: $query " );
			
			if( $qresult !== false ) {
				# if at least one table is present in the query result
				if( $qresult->num_rows > 0) {
					// traverse the $qresult and output the name of the table(s)
					while( $row = $qresult->fetch_assoc() ) {
						//echo '<br />'. $row["Tables_in_$wgDBname"];
						$Available_DBTables[]=$row["Tables_in_$wgDBname"];
					}
					$func_result = $Available_DBTables;
				}
				else {	$func_result = false;
						EUVLogging::wf_EUV_DiagnosticsLogging('',"<span style='color:red'>There is no table in $wgDBname </span> ");}

			}	
			$dbclosing = mysqli_close($db_select_obj) or trigger_error("SQL closing - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			if(!$dbclosing) { $func_result = false;  } 
		} 
		else { # Failed to login into the database
				EUVLogging::wf_EUV_DiagnosticsLogging('','<span style="color:red">Error: Can\'t log into the MySQL server. err:'. mysql_error().' </span>' );
				$func_result = false;}		
				
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_Check_Available_DBTables");
		
	return 	$func_result;
	
	}
	
/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_Check_ValidDBUserconfig_json()
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: check if all required table(s) are present as defined in Userconfig.json  
 * Info		:  
 * Function	:    
 * Input	:  
 *			  
 * Output	: All Userconfig.json table(s) are present 		==>  $func_result = true 
 *	     	  Not all Userconfig.json table(s) are present	==>  $func_result = false
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
 
	function wf_EUV_Check_ValidDBUserconfig_json(){
		
		global $wgEUV_UserconfigurationFile;
	
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_Check_ValidDBUserconfig_json");
		$func_result = true;
		
		# Retrieve an list of availabe DB tables of Userconfig_json
		$availabe_DBtables 	= self::wf_EUV_Check_Available_DBTables();
		# Retrieve an list of required DB tables of Userconfig_json
		$required_tables 	= self::wf_EUV_Create_Default_Tables_query();

		# Check if the required tables are Available 
		foreach ( $required_tables as $EUVTableKey => $value ){
			if ( in_array($EUVTableKey, $availabe_DBtables) ){
				EUVLogging::wf_EUV_DiagnosticsLogging(''," $EUVTableKey table exist ");
				}
				else { 	$func_result = false;
				EUVLogging::wf_EUV_DiagnosticsLogging(''," <span style='color:red'>$EUVTableKey table not found </span> ");}
		}
		
		# whenever we have the correct DB tables availabe, we need to verify the version consistancy
		if ( $func_result){
			$fd 	= __DIR__ .'/../'.$wgEUV_UserconfigurationFile;
			$Presentchksum = md5( file_get_contents($fd) );
			# Retrieve out of the table	QBOX_EUVinternalparameters, the value of EUVPresentUserconfigjsonmd5
			$stored_DBchksum = self::wf_EUV_DBRetrieve_jsonRecords('EUVinternalparameters','EUVPresentUserconfigjsonmd5');
			
			if( $stored_DBchksum != $Presentchksum){
			$func_result = false;
				EUVLogging::wf_EUV_DiagnosticsLogging(''," <span style='color:red'>Checksum userconfig.json differs from DB. We require an update</span> ");}
		}
		
	EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_Check_ValidDBUserconfig_json");	
	return 	$func_result;
	
	}
	
	
/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_DBReadUserconfig_jsonRecords()
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: check if all required table(s) are present as defined in Userconfig.json  
 * Info		:  
 * Function	:    
 * Input	:  
 *			  
 * Output	: All Userconfig.json table(s) are present 		==>  $func_result = true 
 *	     	  Not all Userconfig.json table(s) are present	==>  $func_result = false
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
 
	function wf_EUV_DBReadUserconfig_jsonRecords(){
		
		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname,$wgDBprefix;
	
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_DBReadUserconfig_jsonRecords");
		
		$func_result = false;
		
		$db_select_obj = mysqli_connect( $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname);
		if ( !$db_select_obj == null ){
			
			mysqli_set_charset($db_select_obj, "UTF8");
			
			# First retrieve the table that contains to the required Userconfig_json table(s)
			$tnam = $wgDBprefix.'EUVuserconfigVersions';
			EUVLogging::wf_EUV_DiagnosticsLogging('',"Retrieve the DB Table $tnam");	
			
			$query 	= "SELECT * FROM $tnam ";
			$result = mysqli_query($db_select_obj,$query) or trigger_error("mysqli_query - Error: ". mysqli_error($db_select_obj), E_USER_ERROR);
			$table_array = $result->fetch_assoc();
			$reqTables;
			# put the table names into an array
			# The key is the text EUV inside the name
			foreach ( $table_array as $EUVTableKey => $value ){ 
					if( strpos( $EUVTableKey,"EUV" )> -1 ) { 
						$reqTables[] = $EUVTableKey; 
						EUVLogging::wf_EUV_DiagnosticsLogging('',"Found an EUVTableKey request for $EUVTableKey");
						}
			}
			//print'<pre>';print_r($reqTables);print'</pre>';
			
			# Now retrieve the identified table(s)
			$Userconfig_json;
			foreach ( $reqTables as $EUVTableKey  ){
				$tnam = $wgDBprefix.$EUVTableKey;
				$query 	= "SELECT * FROM $tnam ";
			    $result = mysqli_query($db_select_obj,$query) or trigger_error("mysqli_query - Error: ". mysqli_error($db_select_obj), E_USER_ERROR);
				$Userconfig_json[$EUVTableKey] = $result->fetch_assoc();
				EUVLogging::wf_EUV_DiagnosticsLogging('',"Added result to Userconfig_json[$EUVTableKey] of mysqli_query $query" );
			}
			//print'<pre>';print_r($Userconfig_json);print'</pre>';
			
			$dbclosing = mysqli_close($db_select_obj) or trigger_error("SQL closing - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			if($dbclosing) { $func_result = $table_array; } else { $func_result = false; }
		} 
	
	EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_DBReadUserconfig_jsonRecords");
	
	return $Userconfig_json;
	
	}

/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_DBUpdate_jsonRecords()
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: check if all required table(s) are present as defined in Userconfig.json  
 * Info		:  
 * Function	:    
 * Input	:  
 *			  
 * Output	: All Userconfig.json table(s) are present 		==>  $func_result = true 
 *	     	  Not all Userconfig.json table(s) are present	==>  $func_result = false
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
 
	function wf_EUV_DBUpdate_jsonRecords($json_table,$json_item,$value){
		
		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname,$wgDBprefix,$wgEuvUserconfig_json;
	
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_DBUpdate_jsonRecords");
		
		$func_result = false;
		
		$db_select_obj = mysqli_connect( $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname);
		if ( !$db_select_obj == null ){
			
			mysqli_set_charset($db_select_obj, "UTF8");
			
			$id 	= $wgEuvUserconfig_json[$json_table]['id'];
			EUVLogging::wf_EUV_DiagnosticsLogging('',"Request to DB for update wgEuvUserconfig_json[$json_table]['id']");
			$tnam 	= $wgDBprefix.$json_table;
			$query	= "UPDATE $tnam SET $json_item = '$value' WHERE id = '$id'";
			$result = mysqli_query($db_select_obj,$query) or trigger_error("SQL Ce Updating - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			
			$dbclosing = mysqli_close($db_select_obj) or trigger_error("SQL closing - Error: ". mysqli_error($mysqli), E_USER_ERROR);
			if($dbclosing) { $func_result = $result; } else { $func_result = false; }
		} 
	
	EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_DBUpdate_jsonRecords");
	
	return $func_result;
	
	}	
	
/**********************************
 * Class	: EUVDBaseCreateDefaultTables
 * ID		: wf_EUV_DBRetrieve_jsonRecords($json_table,$json_item)
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	:  
 * Info		:  
 * Function	:    
 * Input	:  
 *			  
 * Output	:  
 *	     	   
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
 
	function  wf_EUV_DBRetrieve_jsonRecords($json_table,$json_item){
		
		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname,$wgDBprefix,$wgEuvUserconfig_json;
	
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_DBRetrieve_jsonRecords");
		
		$func_result = false;
		
		$db_select_obj = mysqli_connect( $wgDBserver,$wgDBuser,$wgDBpassword,$wgDBname);
		if ( !$db_select_obj == null ){
			
			mysqli_set_charset($db_select_obj, "UTF8");
			
			$id 		= 1;
			EUVLogging::wf_EUV_DiagnosticsLogging('',"Request to retrieve from DBtable:$json_table parameter:$json_item");
	
			$utabl		= $wgDBprefix.$json_table;
			$query		= "SELECT $json_item FROM $utabl  WHERE id = '$id' ";	
			$result 	= mysqli_query( $db_select_obj,$query ) or trigger_error("SQL read - Error: ". mysqli_error($db_select_obj), E_USER_ERROR);
			$qresult	= $result->fetch_array();
			$DBresult	= $qresult[0];
			
			$dbclosing = mysqli_close($db_select_obj) or trigger_error("SQL closing - Error: ". mysqli_error($db_select_obj), E_USER_ERROR);
			
			if($dbclosing) { $func_result = $DBresult; } else { $func_result = false; }
			} 
		
	EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_DBRetrieve_jsonRecords");
	return $func_result;
	
	}		
	
}
