<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVDBaseMySQLBackup {
	
	function __construct(){

		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVDBaseMySQLBackup'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVDBaseMySQLBackup',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info		
		global 	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVLogging'] = array(
					'EUVfilename'           			=> 'EUVLogging.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_MySQL_Backup'			=> array(
							'EUVhelp_page'				=> 'wf_EUV_MySQL_Backup help page',
							'EUVphp_design_page'		=> 'wf_EUV_MySQL_Backup design page',
						),
						'wf_EUV_DisplayAllMySQLBackups'			=> array(
							'EUVhelp_page'				=> 'wf_EUV_DisplayAllMySQLBackups help page',
							'EUVphp_design_page'		=> 'wf_EUV_DisplayAllMySQLBackups design page',
						),							
					));
				
	}
	
	const	EUV_MySQL_Backup_folder  = '/mysql_backup';
	
/**********************************
 * Class	: EUVDBaseMySQLBackup
 * ID		: wf_EUV_MySQL_Backup
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Impementation of EUV
 *
 * Purpose	: Create an backup of an database inside the the MySQL database   
 * Info		:  
 * Function	: MySQL backup in an .sql file
 * Input	: $table_name
 *			  
 * Output	: Success ==>  The new MySQL Backup file name
 *	     	  Failure ==>  False
 * Error	:
 * Example	:  new EUVDBaseMySQLBackup();
 * 			   $result_info = $obj->wf_EUV_MySQL_Backup($wgDBname); 
 * Implementation :   
 *  
 */	
	function wf_EUV_MySQL_Backup($table_name) {

		global $wgDBserver,$wgDBuser,$wgDBpassword,$wgUploadDirectory,$wgEUV_QBox_mysqldump;

		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_MySQL_Backup");
		$wg_Backup_result				= true;
		$wg_Local_diagmsg_html			=' start trace';
		$wg_Local_errormsg_html			=' start trace';
		$today							= date("Y-m-d_H-i");
		$MySQL_version					= date("Ymd_His");
		$dest_path						= $wgUploadDirectory.self::EUV_MySQL_Backup_folder;

		EUVLogging::wf_EUV_DiagnosticsLogging('',"checking if folder $dest_path exist");
		if( !is_dir( $dest_path ) ){ 
			EUVLogging::wf_EUV_DiagnosticsLogging('',"creating new directory $dest_path");			
			mkdir($dest_path, 0777);
			chmod($dest_path, 0774);
			}
		$chdir = chdir($dest_path); if (!$chdir) {trigger_error("wf_EUV_MySQL_Backup error: Failed to chdir to $dest_path" , E_USER_ERROR);}
		getcwd();
	
		if( !$table_name ){ 
			$FullFileName 	= $dest_path.'/MYSQL_QNAP459_backup_ALL_'.$MySQL_version.'.sql'; 
			$bnt_mysql = '--all-databases ';
				}
				else  { $FullFileName 	= $dest_path.'/MYSQL_QNAP459_backup_table_'.$table_name.'_'.$MySQL_version.'.sql';
						$bnt_mysql = $table_name;}
		
		EUVLogging::wf_EUV_DiagnosticsLogging('',"Starting an MySQL backup for table $table_name at $today");
		
		# NOTE: IF there is an error, this error is available in the SQL file...*****...2>&1...*****
		#$cmdline_Backup_MYSQL = '/mnt/ext/opt/mariadb/bin/mysqldump -u<user name> -p<password> -hlocalhost dl_wiki > /share/Web/mediawiki/images/mysql_backup/MYSQL_QNAP459_backup_dl_wiki_xxxxx.sql 2>&1 1> /dev/null';
		$cmdline_Backup_MYSQL = $wgEUV_QBox_mysqldump.' -u'.$wgDBuser.' -p'.$wgDBpassword.' -h'.$wgDBserver.' '.$bnt_mysql.' > '.$FullFileName.' 2>&1 ';
		
		EUVLogging::wf_EUV_DiagnosticsLogging('',"creating new backup file: $FullFileName");
		EUVLogging::wf_EUV_DiagnosticsLogging('',"MySQL command line :  $cmdline_Backup_MYSQL");
	
		$output 				= shell_exec($cmdline_Backup_MYSQL);
		EUVLogging::wf_EUV_DiagnosticsLogging('',"The result of the backup was : $output");
	
		$MySQL_Backup_filesize 	= filesize($FullFileName);
		EUVLogging::wf_EUV_DiagnosticsLogging('',"The file size is: $MySQL_Backup_filesize");
		
		if ($MySQL_Backup_filesize < 1000){
			EUVLogging::wf_EUV_DiagnosticsLogging('',"<span style='color:red'>MySQL Backup filesize is too small. We expect that an error has occured</span>");
			$wg_Backup_result	= false;
			}
			else
				{	
				EUVLogging::wf_EUV_DiagnosticsLogging('',"MySQL backup for Data Base $table_name at $today succeeded");
				EUVLogging::wf_EUV_DiagnosticsLogging('',"The new backup file is $FullFileName");
				$wg_Backup_result		= $FullFileName;}
				
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_MySQL_Backup");
	
	return  $wg_Backup_result;
	
 }
 
 /**********************************
 * Class	: EUVDBaseMySQLBackup
 * ID		: wf_EUV_DisplayAllMySQLBackups
 *			   
 * Release	: NA 
 * Date		:  
 * Notes	: Implementation of EUV
 *
 * Purpose	: Display the the MySQL database .sql files  
 * Info		:  
 * Function	: Display the the MySQL database .sql files  
 * Input	:  
 *			  
 * Output	: Success ==>  The MySQL Backup file names
 *	     	  Failure ==>  False
 * Error	:
 * Example	:  new EUVDBaseMySQLBackup();
 * 			   $result_info = $obj->wf_EUV_DisplayAllMySQLBackups(); 
 * Implementation :   
 *  
 */	
 
 
 	function wf_EUV_DisplayAllMySQLBackups() {
		
		global $wgUploadDirectory,$wgServer,$wgScriptPath;

		$dir    = $wgUploadDirectory.self::EUV_MySQL_Backup_folder;
		$dfiles;
		
		if ($handle = opendir($dir)) {
			# This is the correct way to loop over the directory.
			
			while (false !== ($file = readdir($handle))) {
				# filter some exceptions
				
				if ( $file != "." && $file != ".."  && (strpos($file,'MYSQL_QNAP459') === 0) ) {
					$dfiles[] = $file;
					}
			}
		closedir($handle);
		rsort($dfiles);
		
		$html_result = " \r\n";
		$html_result .= '{|class="wikitable sortable mw-collapsible mw-collapsed" cellpadding="0" cellspacing="0" style="white-space: nowrap;font-size:12px;" '."\r\n";
		$html_result .= "|style='background:#ffdead;' | ''' CLICK EXPAND TO VIEW THE MySQL Backup's , OR COLLAPSE TO HIDE THE MySQL Backup's''' "."\r\n";
		$html_result .= "|- \r\n| \r\n";
		
		$result ="{| \n\r|-\n\r";
		
			foreach ($dfiles as $file){
				
				$flink   = "$wgServer$wgScriptPath/images".self::EUV_MySQL_Backup_folder."/$file";
				
				$result .="|[$flink $file ] \n\r|-\n\r"; 
				
				}
			$result .="|}\n\r";
			
			}
			
		$html_result .= $result	;
		
		$html_result .= '|}'."\r\n";
		
	return $html_result;	
		
	}
	
}
