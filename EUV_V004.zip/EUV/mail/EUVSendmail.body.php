<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVSendmail {
	
	function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVSendmail'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVSendmail',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info	
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVSendmail'] = array(
					'EUVfilename'           			=> 'EUVSendmail.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_Send_Email'				=> array(
							'EUVhelp_page'				=> 'wf_EUV_Send_Email help page',
							'EUVphp_design_page'		=> 'wf_EUV_Send_Email design page',
						),						
					));
						
				
	}	
			
/**********************************
 * Class	: EUVSendmail
 * ID		: wf_EUV_ftpCheck
 * Release	: NA 
 * Date		: Created 17-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Sendmail 
 * Info		:  
 * Action  	: Extract all the available pare and interface parameters
 * Input   	: $type      :  the body content 'plain' or 'html'
 *            $TO	     :	Valid email address
 *			  $SUBJECT   :  The subject of the email
 *            $EMAIL_BODY:  The content of the Email
 *			  
 * Output	: TRUE if the mail was successfully accepted for delivery
 *			  FALSE if the mail failed 
 * Error	:
 * Example 	: $obj = new EUVSendmail();
 * 			  $result = $obj->wf_EUV_Send_Email('plain','qbox4u@gmail.com','plain test 1',"sorry....this is an test\nPlease delete this mail\n"); 
 *            $result = $obj->wf_EUV_Send_Email('html','qbox4u@gmail.com','html test 1 ','<h1>Please delete this mail!</h1>'); 
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_Send_Email($type,$TO,$SUBJECT,$EMAIL_BODY){
		
		EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** Start wf_EUV_Send_Email");

$Emtop = <<<EOMHT
This is an automated EUV message from the https://qbox4u.com:8081/conf/rpc/mwk/index.php?title=Main_Page and qbox4u.com server 
and contains automated generated information from  https://www.linkedin.com/in/jan-boer-a24640113
We are pleased to inform you about the following subject 
\n\n
EOMHT;

$Embot = <<<EOBOT
\n\n
The information contained in this communication and any attachments is confidential and may be privileged, 
and is for the sole use of the intended recipient(s). 
Any unauthorized review, use, disclosure or distribution is prohibited. Unless explicitly 
stated otherwise in the body of this communication or the attachment thereto (if any), the 
information is provided on an AS-IS basis without any express or implied warranties or liabilities. 
To the extent you are relying on this information, you are doing so at your own risk. If you are 
not the intended recipient, please notify the sender immediately by replying to this message and 
destroy all copies of this message and any attachments. QBox is neither liable for the proper and 
complete transmission of the information contained in this communication, nor for any delay in its receipt. 

EOBOT;

		$Emtop1 	= str_replace("\n.", "\n..", $Emtop);
		$Email_Body = preg_replace("#(?<!\r)\n#si", "\r\n", $EMAIL_BODY); 
		# limit the email line width to 70 characters
		$Email_Body = wordwrap($Email_Body, 70, "\r\n");
		# the email receiver and subect
		$to      	= $TO;
		$subject 	= $SUBJECT;
		# define the required mail parameters
		$headers   = array(); 
			$headers[] = "MIME-Version: 1.0";
			# check if we require an pain text email, or an HTML content mail
			if($type == 'plain'){$headers[] = "Content-type: text/plain; charset=iso-8859-1";}
						    else{$headers[] = "Content-type: text/html; charset=iso-8859-1";}
			$headers[] = "Content-type: text/plain; charset=iso-8859-1";
			$headers[] = "Content-type: text/html; charset=iso-8859-1";
			$headers[] = "From: qbox4u@gmail.com"; 
			# Bcc and CC not impemented
			$headers[] = "Bcc: ";
			$headers[] = "Reply-To: qbox4u@gmail.com";
			$headers[] = "Subject: {$subject}";
			$headers[] = "X-Mailer: PHP/".phpversion();
		
		EUVLogging::wf_EUV_DiagnosticsLogging('',"perform an email to: $to subject:$subject");
		# perform the actual mail
		$result 	= mail($to, $subject, $Emtop.$Email_Body.$Embot , implode("\r\n", $headers));
		EUVLogging::wf_EUV_DiagnosticsLogging('',"The result of email to: $to subject:$subject is: $result");
		
	EUVLogging::wf_EUV_DiagnosticsLogging('F',"***** End wf_EUV_Send_Email");
	# return the mail send status
	return $result;	
		
	}
	
}
