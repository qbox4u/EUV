<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVDispayLoggingfiles {

	function __construct(){

		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVDispayLoggingfiles'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVDispayLoggingfiles',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info		
		global 	$wgEUVFuncinfo,$wgScriptPath;
				$wgEUVFuncinfo['EUVDispayLoggingfiles'] = array(
					'EUVfilename'           			=> '/logging/EUVDispayLoggingfiles.body',
					'EUVfunctions'						=> array( 
						'wf_EUV_DispayLoggingfiles'		=> array(
							'EUVhelp_page'				=> 'wf_EUV_DispayLoggingfiles help page',
							'EUVphp_design_page'		=> 'wf_EUV_DispayLoggingfiles design page',
						),					
				));
				
	}

/**********************************
 * Class	: EUVDispayLoggingfiles
 * ID		: wf_EUV_DispayLoggingfiles
 * Release	: NA 
 * Date		: Created 30-10-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	: display the EUV Diagnostics logging files 
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_DispayLoggingfiles() { 
		global $wgUser,$wgUploadDirectory;
			
			$EUV_logging_folder		= $wgUploadDirectory.EUVLogging::EUV_folder.EUVLogging::EUV_logging_folder;
			$LocalWikiText 			= '';
			$dfiles;

			# Read all file names from an certain director
			if ($handle = opendir($EUV_logging_folder)) {
				
				# This is the correct way to loop over the directory.  
				while ( false !== ( $file = readdir($handle) ) ) { 
				
					# Filter the required EUV logging files out of the folder and store the individual paths inside $dfiles
					# Search therefore for the correct EUV logging file extension 
					$Diagnostics_logging_file = EUVLogging::EUV_Diagnostics_logging_file;
					$File_extension = '.'.pathinfo($Diagnostics_logging_file, PATHINFO_EXTENSION);
					if ( ($file !== '.') && ($file !== '..' ) && (strpos($file,$File_extension) > 0) ){ $dfiles[] = $file; }

				}
				# Close the handler again
				closedir($handle);
			}
		
			# Sort the files in an alpha numerical way
			rsort($dfiles);

			# Create an Wiki table containing 10 links to the EUV logging files 
			//$LocalWikiText .= "\r\n= Last 10 EUV Diagnostics Logging Files  = \r\n";
			
			//$LocalWikiText .= "{| class=\"wikitable\"\r\n|-\r\n! ID !! EUV Diagnostics Logging Files \r\n|-\r\n";
			$LocalWikiText .= "{| style='border-spacing: 0px; border: 1px solid darkgray;' \r\n|-\r\n!  !! EUV Diagnostics Logging Files \r\n|-\r\n";
			
			$LocalWikiText .="|[[File:File_extension_icon_32px_folder.png|16px|left]]".EUVLogging::EUV_folder;
			
			$LocalWikiText .="||[[File:File_extension_icon_32px_folder.png|16px|left]]".EUVLogging::EUV_logging_folder."\r\n|-\r\n";			
				# Select the first 10 EUV logging files out of the availabe list  
				$i=1;
				foreach ($dfiles as &$value) {
					
					# The Wii part uses the foowing notation 
					# "| ||[[File:<the image>|16px|left|link=<{{SERVER}}{{SCRIPTPATH}} the coming link> |<the popup> ]] [<The source link behind the image>]"."\r\n|-\r\n";
					
					# As spaces inside an html file link confuse Wiki, we have to add %20 on places with an space
					$Wiki_value =  str_replace(" ","%20",$value);
					
					# The total length of the Wiki link makes it in this editor difficut to read, therefore i split it into 3 pieces ^_^ ^_^  
					$a = "| ||[[File:File_extension_icon_32px_edls.png|16px|left|link={{SERVER}}{{SCRIPTPATH}}";
					$b = "/images".EUVLogging::EUV_folder.EUVLogging::EUV_logging_folder.'/'. $Wiki_value ." |$value ]]";				
					$c = " [{{SERVER}}{{SCRIPTPATH}}/images".EUVLogging::EUV_folder.EUVLogging::EUV_logging_folder.'/'. $Wiki_value . " $value ]"."\r\n|-\r\n";

					$LocalWikiText .= $a.$b.$c;
					
					$i++;
					
					if ($i > 9){ break;}
				}
			$LocalWikiText .="|}\r\n";
			
			# Create an Wiki table containing this time .. all the plain links to the EUV logging files
			$LocalWikiText .= "= Complete EUV Diagnostics Logging listing = \r\n";
			$LocalWikiText .= " Press '''Expand''' to show the complete list \r\n";
			
			$LocalWikiText .= "{| class=\"mw-collapsible mw-collapsed wikitable\"\r\n|-\r\n! ID !! EUV Diagnostics Logging Files \r\n|-\r\n";

			# Select the entire logging files list from the availabe list
				$i=1;
				foreach ($dfiles as &$value) {
					$Wiki_value =  str_replace(" ","%20",$value);
					$LocalWikiText .= "|$i||{{SERVER}}{{SCRIPTPATH}}/images".EUVLogging::EUV_folder.EUVLogging::EUV_logging_folder.'/'.$Wiki_value."\r\n|-\r\n";
					$i++;
				}
			$LocalWikiText .="|}\r\n";

		return $LocalWikiText;
		
	}	
	
}
