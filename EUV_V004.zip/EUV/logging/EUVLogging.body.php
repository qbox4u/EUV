<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVLogging {
	
	function __construct(){

		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVLogging'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVLogging',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info		
		global 	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVLogging'] = array(
					'EUVfilename'           			=> 'EUVLogging.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_CheckFilePaths'			=> array(
							'EUVhelp_page'				=> 'wf_EUV_CheckFilePaths help page',
							'EUVphp_design_page'		=> 'wf_EUV_CheckFilePaths design page',
						),
						'wf_EUV_FunctionInfoTimeStamp'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_FunctionInfoTimeStamp help page',
							'EUVphp_design_page'		=> 'wf_EUV_FunctionInfoTimeStamp design page',
						),
						'wf_EUV_InfoTimeStamp'			=> array(
							'EUVhelp_page'				=> 'wf_EUV_InfoTimeStamp help page',
							'EUVphp_design_page'		=> 'wf_EUV_InfoTimeStamp design page',
						),
						'wf_EUV_DiagnosticsLogging'		=> array(
							'EUVhelp_page'				=> 'wf_EUV_DiagnosticsLogging help page',
							'EUVphp_design_page'		=> 'wf_EUV_DiagnosticsLogging design page',
						),
						'wf_EUV_CheckMaxLoggingSize'	=> array(
							'EUVhelp_page'				=> 'wf_EUV_CheckMaxLoggingSize help page',
							'EUVphp_design_page'		=> 'wf_EUV_CheckMaxLoggingSize design page',
						),						
					));
				
	}
	
	const	EUV_folder 								= '/EUV';
	const	EUV_logging_folder  					= '/EUV_Diagnostics_logging';
	const	EUV_Diagnostics_logging_file 			= '/diagnostics_logging.html';
	
	const	EUV_Diagnostics_logging_file_MaxSize 	= '100000'; 				# Max size is 0.1Meg
	const	EUV_Active_Diagnostics_logging			= TRUE;						# Set to FALSE TRUE to activate logging
	const	EUV_Diagnostics_logging_NextTab			= '					|';		# Additional tab in Diagnostics logging file
	

/**********************************
 * Class	: EUVLogging
 * ID		: wf_EUV_ChecFilePaths
 * Release	: NA 
 * Date		: Created 29-10-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	: Check if the required folders for the EUV extension are present and create them if not   
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_CheckFilePaths() { 
		global $wgUser,$wgUploadDirectory;
		
			# retrieve the constants of the folder allocations 
			$EUV_path 						= $wgUploadDirectory.self::EUV_folder;
			$EUV_Diagnostics_logging_path 	= $EUV_path.self::EUV_logging_folder;
			$Log_file						= $EUV_Diagnostics_logging_path.self::EUV_Diagnostics_logging_file;
				
			# add info to the Diagnostics Logging file
			$log = EUVLogging::wf_EUV_FunctionInfoTimeStamp().("Start wf_EUV_CheckFilePaths <br>\r\n");
			
			# Create the EUV and EUV Diagnostics logging folder if they not exist
			$EUV_path 						= $wgUploadDirectory.self::EUV_folder;
			$EUV_Diagnostics_logging_path 	= $EUV_path.self::EUV_logging_folder;
			
			# add info to the Diagnostics Logging file
			$log .= EUVLogging::wf_EUV_InfoTimeStamp().("checking if folder $EUV_path exist <br>\r\n");
			
			# Check for the existance of the appropiate folder 
			if( !is_dir( $EUV_path ) ){ 
			
				# The folder is not present, so we need to create one
				mkdir($EUV_path, 0777);
				# Set the appropiate rights of the folder
				chmod($EUV_path, 0774);
				# add info to the Diagnostics Logging file
				$log .= EUVLogging::wf_EUV_InfoTimeStamp().("$EUV_path does not exist, created new one <br>\r\n");
				# whenever we can't create the folder, create an system error
				if( !is_dir( $EUV_path ) ){ trigger_error("folder $EUV_path creation Error: ", E_USER_ERROR);}
				
			}
				
			# add info to the Diagnostics Logging file
			$log .= EUVLogging::wf_EUV_InfoTimeStamp().("checking if folder $EUV_Diagnostics_logging_path exist <br>\r\n");	
			
			# Check for the existance of the appropiate folder 
			if( !is_dir( $EUV_Diagnostics_logging_path ) ){	
				# The folder is not present, so we need to create one			
				mkdir($EUV_Diagnostics_logging_path, 0777);
				# Set the appropiate rights of the folder
				chmod($EUV_Diagnostics_logging_path, 0774);
				# add info to the Diagnostics Logging file
				$log .= EUVLogging::wf_EUV_InfoTimeStamp().("$EUV_Diagnostics_logging_path, created new one <br>\r\n");
				# whenever we can't create the folder, create an system error
				if( !is_dir( $EUV_Diagnostics_logging_path ) ){ trigger_error("folder $EUV_Diagnostics_logging_path creation Error: ", E_USER_ERROR);}				
				}
			
			# add info to the Diagnostics Logging file			
			$log .= EUVLogging::wf_EUV_FunctionInfoTimeStamp().("End wf_EUV_CheckFilePaths <br>\r\n");	
			
			# Add manually to the Diagnostics logfile
			if( is_dir( $EUV_path ) && is_dir( $EUV_Diagnostics_logging_path ) ){
					if ( self::EUV_Active_Diagnostics_logging ){ file_put_contents($Log_file, $log, FILE_APPEND | LOCK_EX); }
				}	
		
		return;
		
	}	

/**********************************
 * Class	: EUVLogging
 * ID		: wf_EUV_InfoTimeStamp 			.. Used for providing interna function diagnostics feedback 
 *			  wf_EUV_FunctionInfoTimeStamp  .. Used for marking function start and stop
 * Release	: NA 
 * Date		: Created 29-10-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
 
	public static function wf_EUV_FunctionInfoTimeStamp() {
		global $wgUser;		
			
			# retrieve the PID of the present run
			$PID 				= getmypid();
			# Get the present day and time
			$today 				= date("Y-m-j");
			# Get the time in micro seconds
			$Sec 				= microtime();
			list($usec, $sec) 	= explode(" ", microtime());
			
		return $wgUser.'|'.$PID.'|'.$today.' '.' Sec:'. $sec .' uSec:'. $usec.'|';
	}
	
	public static function wf_EUV_InfoTimeStamp() {
		global $wgUser;		
			
			# retrieve the PID of the present run
			$PID 				= getmypid();
			# Get the present day and time
			$today 				= date("Y-m-j");
			# Get the time in micro seconds
			$Sec 				= microtime();
			list($usec, $sec) 	= explode(" ", microtime());
			
		return $wgUser.'|'.$PID.'|'.$today.' '.' Sec:'. $sec .' uSec:'. $usec.'|'.self::EUV_Diagnostics_logging_NextTab;
	}

/**********************************
 * Class	: EUVLogging
 * ID		: wf_EUV_DiagnosticsLogging($sel,$log_info)
 * Release	: NA 
 * Date		: Created 29-10-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	: $sel 		.. 'F' Function start/stop marker 
 *  		  $sel 		.. ''  Info marker
 *			  $log_info .. Data provided for diagnostica analyses
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */	
	public static function wf_EUV_DiagnosticsLogging($sel,$log_info) {
		global $wgUploadDirectory;
		
			# retrieve the constants of the folder allocations
			$EUV_path 						= $wgUploadDirectory.self::EUV_folder;
			$EUV_Diagnostics_logging_path 	= $EUV_path.self::EUV_logging_folder;
			$Log_file						= $EUV_Diagnostics_logging_path.self::EUV_Diagnostics_logging_file;
		
			if ( self::EUV_Active_Diagnostics_logging ){ 
			
				# Add manually the additional data to the Diagnostics logfile
				# Select if we use an function marker ('F') or regular info('')
				If( !empty( $sel ) ) { $pre_gen = EUVLogging::wf_EUV_FunctionInfoTimeStamp(); }
					else { $pre_gen = EUVLogging::wf_EUV_InfoTimeStamp(); }
					
				$new_logging_info 	= $pre_gen.$log_info."<br>\r\n";
				file_put_contents($Log_file, $new_logging_info, FILE_APPEND | LOCK_EX);
			
				# Check if the Diagnostics logfile does not exceed the size limit
				$nf = EUVLogging::wf_EUV_CheckMaxLoggingSize();
				
				# Check if the Diagnostics logfile was backuped an an blank was started again 
				if( !empty( $nf ) ) {
					 
					# add info to the Diagnostics Logging file			
					$new_logging_info = "Previous Diagnostics Logging file stored in $nf. <br>\r\n";
					file_put_contents($Log_file, $new_logging_info, FILE_APPEND | LOCK_EX);
					
					# add info to the Diagnostics Logging file
					$new_logging_info = "Created an new Diagnostics Logging file. <br>\r\n\r\n";
					file_put_contents($Log_file, $new_logging_info, FILE_APPEND | LOCK_EX);
				}
			}
				
		return;
	}

/**********************************
 * Class	: EUVLogging
 * ID		: wf_EUV_CheckMaxLoggingSize()
 * Release	: NA 
 * Date		: Created 29-10-2016 by JBoe
 * Notes	: Impementation of EUV
 *
 * Purpose	:    
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>   
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */		
	public static function wf_EUV_CheckMaxLoggingSize() {
		global $wgUploadDirectory;
		
			# set initial value
			$result 						= '';
			
			# retrieve the constants of the folder allocations
			$EUV_path 						= $wgUploadDirectory.self::EUV_folder;
			$EUV_Diagnostics_logging_path 	= $EUV_path.self::EUV_logging_folder;
			$Log_file						= $EUV_Diagnostics_logging_path.self::EUV_Diagnostics_logging_file;
			
			# Create an backup filename   1917 01 01 _ 24 59 59
			$today 							= date("Ymd_His");
			$BackupLog_file 				= '/'.$today.'_EUVDiagnosticLogging.html';
			$backupf						= $EUV_Diagnostics_logging_path.$BackupLog_file;
			
			if ( self::EUV_Active_Diagnostics_logging ){
				
				# Check if the Diagnostics logfile does not exceed the size limit
				if ( filesize($Log_file) > self::EUV_Diagnostics_logging_file_MaxSize ){

					# The Diagnostics logfile does  exceed the size limit
					# add info to the Diagnostics Logging file
					$new_logging_info = "Diagnostics Logging file exceeds limit. Stored in $BackupLog_file.<br>\r\n";
					file_put_contents($Log_file, $new_logging_info, FILE_APPEND | LOCK_EX);
				  
					# Rename the Diagnostics Logging file
					if ( !rename ( $Log_file, $backupf ) ){ trigger_error("$Log_file could not be renamed. Error: ", E_USER_ERROR); }
					
					# The backup Diagnostics logging filename  
					$result = $backupf; 
				  }
				  
			}
			
		return $result; 
		
	}	
	
	
}
