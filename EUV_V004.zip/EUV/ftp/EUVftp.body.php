<?php
/******************
 *  variable Extension - 
 *  This class is part of and used by an QBox extention
 *  Copyright (C) 2010 qbox4u.com <qbox4u@gmail.com> 
 *
 *  This program is not free software therefore you can-not redistribute 
 *  it and/or modify it under the terms of the GNU General Public License 
 *  as published by the Free Software Foundation; either version 2 of the 
 *  License, or (at your option) any later version.
 *
 *  Please consult and/or request the administrator of qbox4u@gmail.com
 *  to use the information and samples
 *
 *  To copy the data, an written autorisation of the developer as stated 
 *  above and/or in $wgExtensionCredits is required 
 * 
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 *
 *  @ingroup Extensions
 *  @author Jan boer <qbox4u@gmail.com>
 *  @LinkedIn https://www.linkedin.com/in/jan-boer-a24640113
 *  @version 1.0
 *  @link http://QBox4u.com
 *
 */

class EUVftp {
	
	# self::EUV_UDS1100_CharReadTimeout contains the wf_EUV_ReadUDS1100Char time out value
	const EUV_UDS1100_CharReadTimeout 	= 1;
	# self::EUV_UDS1100_LnReadTimeout contains the wf_EUV_ReadUDS1100Ln time out value
	const EUV_UDS1100_LnReadTimeout 	= 2;
	
	function __construct(){
		
		# The EUV extension Credits info
		global	$wgEUVFuncCredits;
				$wgEUVFuncCredits['EUVlantronix'][] = array(
					'version'				=> '1.0.0',
					'path'           		=> __FILE__,
					'author' 				=>  array( 'private' =>'https://www.linkedin.com/in/jan-boer-a24640113','email'=>'qbox4u@gmail.com'),
					'description' 			=> 'PHP Master: Class EUVftp',
					'license-name' 			=> 'Licence',
					'test_url' 				=> 'https://qbox4u.com:8081/conf/tech/mwk/index.php?title=Main_Page'
				);
				
		# The EUV extension Class info	
		global	$wgEUVFuncinfo;
				$wgEUVFuncinfo['EUVftp'] = array(
					'EUVfilename'           			=> 'EUVftp.body.php',
					'EUVfunctions'						=> array( 
						'wf_EUV_ftpCheck'				=> array(
							'EUVhelp_page'				=> 'wf_EUV_ftpCheck help page',
							'EUVphp_design_page'		=> 'wf_EUV_ftpCheck design page',
						),						
					));
						
				
	}	
			
/**********************************
 * Class	: EUVphpbinchk
 * ID		: wf_EUV_ftpCheck
 * Release	: NA 
 * Date		: Created 15-11-2016 by JBoe
 * Notes	: Impementation of EUV 
 *
 * Purpose	: Check for the ftp performance   
 * Info		:  
 * Function	:  
 * Input	:  
 *			  
 * Output	: Success ==>    
 *	     	  Failure ==>  
 * Error	:
 * Example	:      
 * Implementation :   
 *  
 */
 
	public static function wf_EUV_ftpCheck() {
		

		$FunctionError_status 	= False; 
		$Function_result		= '';
		
		$ftp_server 			= 'ftp.ed.ac.uk'; 
		$ftp_user_name			= 'anonymous'; 
		$ftp_user_pass			= 'qbox4u@gmail.com';
		
		$EUV_ftpconn_id  		= ftp_connect($ftp_server);
		if ( ( $EUV_ftpconn_id ) ) {
			$Function_result .= " Connection is established to $ftp_server"."\n\r";
			$login_result = ftp_login( $EUV_ftpconn_id ,$ftp_user_name,$ftp_user_pass );
			if ( ( $login_result ) ) {
				$Function_result .= " Successfully logged in as user: $ftp_user_name"."\n\r";
				$new_folder = '/';
				$buff = ftp_rawlist ( $EUV_ftpconn_id, $new_folder);
				$Function_result .= " <b>'''Listing of the server $ftp_server folder: $new_folder'''</b>"."\n\r";
				foreach ($buff as $key){
					$Function_result .= "$key"."\n\r";
				}
				$new_folder = '/pub';
				$Function_result .=" <b>'''Sorted listing of the server $ftp_server folder: $new_folder'''</b>"."\n\r";
				if( ftp_chdir( $EUV_ftpconn_id ,$new_folder ) ){
					$nfbuff = ftp_nlist ( $EUV_ftpconn_id, "-a ".$new_folder);
					sort($nfbuff, SORT_NATURAL );
					//$nfbuff = ftp_nlist ( $EUV_ftpconn_id, $new_folder);
					$nroffiles = count($nfbuff);
					if ($nroffiles < 35 ) {
						# the number of availabe files is less than expected
						$Function_result .= " WARNING: The number of availabe files inside $new_folder is less than the expected 40"."\n\r";
						$FunctionError_status = True;}
						
					$Function_result .="{| border='1' \n\r|- \n\r";
					$Function_result .="|+ Found files inside folder: $new_folder \n\r";
					$i=0;
					foreach ($nfbuff as $nfkey){
						$i++;
						//$Function_result .= "$nfkey"."\n\r";
						if ($i > 6){ 
							$i=1; 
							$Function_result .="|- \n\r|$nfkey \n\r";
							}
							else { $Function_result .="|$nfkey \n\r"; }
						
						}
					$Function_result .="|- \n\r|} \n\r";
					}
					else { 
						$FunctionError_status = True;
						$Function_result .= " Error trying to change directory to $new_folder"."\n\r"; }
			}
			else { # Error trying to login as anonymous user
				$FunctionError_status = True;
				$Function_result .= " Error trying to login as user: $ftp_user_name"."\n\r"; }			
			ftp_close( $EUV_ftpconn_id ); 
		}
        else{ # We could not establish an FTP connection
			$FunctionError_status = True;
			$Function_result .= " NO connection established to server: $ftp_server"."\n\r"; }
			
	return $Function_result;
		
	}
	
}
